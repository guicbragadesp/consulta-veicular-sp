'use strict';
function portalStep(q) {
  const visible=e=>e&&e.getClientRects().length>0;
  const clean=s=>String(s||'').replace(/\s+/g,' ').trim();
  const norm=s=>String(s||'').replace(/\D/g,'').replace(/^0+/,'');
  const label=e=>clean(e.value||e.innerText||e.textContent);
  const rows=[...document.querySelectorAll('tr')].filter(visible);
  const field=document.getElementById('consultaDebitoForm:decTxtTipoConsulta:renavam');
  const debts=[];
  if(field&&norm(field.value)===norm(q.renavam)) for(const row of rows){
    const links=[...row.querySelectorAll('a')].filter(e=>visible(e)&&/^Liquidar\s*\/?$/i.test(label(e)));
    const ids=[...row.cells].map(c=>clean(c.innerText)).filter(s=>/^\d{8,15}$/.test(s));
    if(links.length===1&&ids.length===1&&!debts.some(d=>d.cda===ids[0]))debts.push({cda:ids[0],text:clean(row.innerText),link:links[0]});
  }
  if(q.action==='list')return debts.map(({cda,text})=>({cda,text}));
  if(q.action==='liquidar'){const d=debts.find(d=>d.cda===q.cda);if(!d)return 'waiting';d.link.click();return 'clicked';}
  const body=clean(document.body.innerText);
  if(q.action==='position')return {listed:debts.length>0,signature:body};
  // The informational popup can reappear on return and its close control is
  // a RichFaces div/image, not necessarily a button or a semantic dialog.
  if(q.action==='download'||q.action==='back'){
    const panels=[...document.querySelectorAll('[role="dialog"],.rich-modalpanel,.rich-mpnl-content,.rf-pp-cntr,.ui-dialog')].filter(e=>visible(e)&&/Importante/i.test(e.innerText)&&/duas guias/i.test(e.innerText));
    for(const panel of panels){
      const scope=panel.closest('.rich-modalpanel,.rf-pp-cntr,.ui-dialog,[role="dialog"]')||panel;
      const closeButton=[...scope.querySelectorAll('.ui-dialog-titlebar-close,.rf-pp-hdr-cntr .rf-pp-close')].find(visible);
      if(closeButton){closeButton.click();return 'notice-closed';}
      const closer=[...scope.querySelectorAll('button,a,img,input,span,div')].filter(visible).find(e=>/^(fechar|close|×|x)$/i.test(clean(e.getAttribute('aria-label')||e.title||e.alt||e.innerText))||/(?:close|closer|rich-mpnl-controls)/i.test(String(e.className||'')+' '+String(e.id||'')+' '+String(e.getAttribute('src')||'')));
      if(closer){const target=/rich-mpnl-controls/i.test(String(closer.className||''))?(closer.querySelector?.('img,button,a,span')||closer):closer;target.click();return 'notice-closed';}
      return 'waiting'; // Never click a covered Download/Voltar button.
    }
  }
  const id=body.match(/(?:N[º°o]?\s*(?:de\s*)?Registro\s*\/\s*CDA|CDA)\s*:\s*(\d+)/i);
  if((!id||id[1]!==q.cda)&&!((q.action==='download'||q.action==='back')&&q.verifiedCda===q.cda))return 'waiting';
  const controls=[...document.querySelectorAll('a,button,input[type="button"],input[type="submit"]')].filter(visible);
  if(q.action==='back'){
    const buttons=controls.filter(e=>/^Voltar$/i.test(label(e)));if(buttons.length!==1)return 'waiting';buttons[0].click();return 'clicked';
  }
  if(q.action==='gerar'){
    if(!rows.some(r=>[...r.cells].some(c=>norm(clean(c.innerText))===norm(q.renavam))))return 'waiting';
    const buttons=controls.filter(e=>/^Gerar (?:D|G)ARE$/i.test(label(e)));if(buttons.length!==1)return 'waiting';buttons[0].click();return 'clicked';
  }
  if(q.action==='download'){
    const buttons=controls.filter(e=>/^Download (?:d[ao] )?(?:D|G)ARE$/i.test(label(e)));if(buttons.length!==1)return 'waiting';buttons[0].click();return 'clicked';
  }
  return 'waiting';
}
function create({getWindow,getState,shell,destination,verifyPdf=require('./pge-pdf').verifyPdf}){
  const fs=require('node:fs'),path=require('node:path');let running=false;
  const valid=w=>w&&!w.isDestroyed()&&/^https:\/\/www\.dividaativa\.pge\.sp\.gov\.br\//.test(w.webContents.getURL());
  async function execute(w,q){if(!valid(w))throw Error('Abra a tabela de débitos da PGE deste veículo.');return w.webContents.executeJavaScript('('+portalStep.toString()+')('+JSON.stringify(q)+')');}
  async function list(){const s=getState();if(!s||s.pge.status!=='complete')throw Error('Conclua a pesquisa da PGE antes de emitir guias.');const items=await execute(getWindow(),{action:'list',renavam:s.input.renavam});if(!items.length)throw Error('Deixe aberta na PGE a tabela das CDAs deste Renavam, com os links Liquidar.');return {renavam:s.input.renavam,items};}
  async function generate(selection){
    if(running)throw Error('Já existe uma emissão em andamento.');
    const current=await list();
    if(!selection||selection.renavam!==current.renavam||!Array.isArray(selection.cdas)||!selection.cdas.length||selection.cdas.some(id=>!current.items.some(i=>i.cda===id)))throw Error('Selecione novamente as CDAs deste veículo.');
    running=true;
    const w=getWindow(),s=getState(),wc=w.webContents,selected=[...new Set(selection.cdas)];
    const folder=path.join(destination,'Guias PGE '+s.input.plate+' '+new Date().toISOString().replace(/[:.]/g,'-'));
    const downloadSession=wc.session;
    let verifiedCda=null,cda=null,downloads=[],failure=null,lastDownloadAt=0;const files=[],childIds=new Set([wc.id]);
    const childListener=child=>childIds.add(child.webContents.id);
    const downloadListener=(event,item,source)=>{
      if(!cda||!source||!childIds.has(source.id))return;
      if(!/^https:\/\/www\.dividaativa\.pge\.sp\.gov\.br\//.test(item.getURL()))return;
      const filename=path.basename(item.getFilename()).replace(/[^\p{L}\p{N}_. -]/gu,'_');
      const file=path.join(folder,cda+'-'+(downloads.length+1)+'-'+filename);item.setSavePath(file);
      const record={done:false,file};downloads.push(record);lastDownloadAt=Date.now();const downloadCda=cda;
      item.once('done',(_e,status)=>{record.done=true;lastDownloadAt=Date.now();if(status==='completed')files.push(file);else failure='Download interrompido na CDA '+downloadCda;});
    };
    const waitFor=async predicate=>{const deadline=Date.now()+60000;while(Date.now()<deadline){if(w.isDestroyed()||getState()!==s)throw Error('A consulta mudou ou a janela foi fechada.');if(failure)throw Error(failure);if(await predicate())return;await new Promise(r=>setTimeout(r,600));}throw Error('A PGE não confirmou esta etapa. Confira o aviso e os downloads na janela do portal.');};
    const step=action=>waitFor(async()=>{if(wc.isLoadingMainFrame())return false;try{return await execute(w,{action,renavam:current.renavam,cda,verifiedCda})==='clicked';}catch{return false;}});
    try{
      fs.mkdirSync(folder,{recursive:true});wc.on('did-create-window',childListener);downloadSession.on('will-download',downloadListener);w.show();w.focus();
      for(const id of selected){
        cda=id;verifiedCda=null;downloads=[];
        await step('liquidar');await step('gerar');verifiedCda=cda;await step('download');
        await waitFor(()=>downloads.length>=1&&downloads.every(d=>d.done)&&Date.now()-lastDownloadAt>=1500);
        for(const download of downloads)await verifyPdf(download.file,cda);
        // JSF pages depend on POST state: use the portal's own Voltar buttons.
        for(let returns=0;returns<3;returns++){
          const before=await execute(w,{action:'position',renavam:current.renavam,cda});
          if(before.listed)break;
          await step('back');
          await waitFor(async()=>{
            if(wc.isLoadingMainFrame())return false;
            const after=await execute(w,{action:'position',renavam:current.renavam,cda});
            return after.listed||after.signature!==before.signature;
          });
        }
        await waitFor(async()=>!wc.isLoadingMainFrame()&&(await execute(w,{action:'list',renavam:current.renavam})).some(item=>item.cda===selected[Math.min(selected.indexOf(id)+1,selected.length-1)]));
      }
      await shell.openPath(folder);return {files:files.length,cdas:selected.length,folder};
    }catch(error){if(fs.existsSync(folder))await shell.openPath(folder);throw Error(error.message+' Emissão interrompida na CDA '+(cda||'—')+'. '+files.length+' arquivo(s) já salvo(s) em '+folder+'. Confira os arquivos antes de emitir novamente.');}
    finally{cda=null;running=false;downloadSession.removeListener('will-download',downloadListener);if(!wc.isDestroyed())wc.removeListener('did-create-window',childListener);}
  }
  return {list,generate,get running(){return running;}};
}
module.exports={portalStep,create};
