﻿$ErrorActionPreference = 'Stop'
Write-Host 'Feche o Braga antes de atualizar.'
$bragaFolder = (Read-Host 'Pasta do Braga (que contem app e runtime)').Trim('"')
$bragaRoot = (Resolve-Path -LiteralPath $bragaFolder).Path
if (!(Test-Path -LiteralPath (Join-Path $bragaRoot 'app\package.json')) -or !(Test-Path -LiteralPath (Join-Path $bragaRoot 'runtime'))) { throw 'Pasta do Braga invalida.' }
$bragaTarget = Join-Path $bragaRoot 'app'
$bragaSource = Join-Path $PSScriptRoot 'app'
$bragaBackup = Join-Path $bragaTarget ('backup-1930-'+(Get-Date -Format 'yyyyMMdd-HHmmss'))
New-Item -ItemType Directory -Path $bragaBackup | Out-Null
Get-ChildItem -LiteralPath $bragaSource -File | ForEach-Object {
  $bragaDestination = Join-Path $bragaTarget $_.Name
  if (Test-Path -LiteralPath $bragaDestination) { Copy-Item -LiteralPath $bragaDestination -Destination (Join-Path $bragaBackup $_.Name) }
  Copy-Item -LiteralPath $_.FullName -Destination $bragaDestination -Force
  if ((Get-FileHash -LiteralPath $_.FullName).Hash -ne (Get-FileHash -LiteralPath $bragaDestination).Hash) { throw ('Falha ao verificar '+$_.Name) }
}
Write-Host 'Braga 1.9.30 atualizado. Reabra o programa.'
