const { test } = require('node:test');
const assert = require('node:assert/strict');
const { cents, normalizeInput, parseFazenda, parsePge, quote, quoteText } = require('../domain');

// Dados de regressão das consultas observadas, sem dados pessoais de proprietários.
const input = normalizeInput({ plate: 'FOE4G55', renavam: '01026263821', fee: '100' });
function fiorino() {
  return { plate: 'FOE4G55', renavam: '1026263821', model: 'FIAT/FIORINO 1.4 FLEX', year: '2014',
    ipvaHeading: 'IPVA 2026', ipva: '(3) IPVA Apurado R$ 903,58 (8) Saldo R$ 903,58 (9) Acréscimos Legais R$ 276,12 (10) Valor a pagar (10)=(8)+(9) R$ 1.179,70',
    priorPresent: true, priorText: 'NADA CONSTA', priorRows: [], licensingPresent: true,
    licensing: '> Licenciamento 2026 R$ 174,08 (1) Taxa Devida R$ 174,08 (2) Multa R$ 0,00 (3) Juros R$ 0,00 (4) Valor a Pagar (4)=(1)+(2)+(3) R$ 174,08',
    finesPresent: true, finesText: 'R$ 5.303,32',
    fineRows: [['Órgão','Quantidade','Valor','Total'],['MUNICIPAL','4','R$ 825,18','R$ 825,18'],['DETRAN','4','R$ 1.557,96','R$ 1.557,96'],['D.E.R.','5','R$ 1.227,78','R$ 1.227,78'],['RENAINF','8','R$ 1.692,40','R$ 1.692,40'],['R$ 5.303,32']],
    totalText: 'Total de Débitos (exceto débitos em dívida ativa): R$ 6.657,10' };
}
test('soma fiel à consulta real: R$ 6.757,10, sem duplicar IPVA, parcelas ou totais', () => {
  const fazenda = parseFazenda(fiorino(), input);
  assert.equal(fazenda.status, 'complete');
  const pge = parsePge({ noDebts: true, renavam: '01026263821' }, input, true);
  const result = quote({ input, fazenda, pge });
  assert.equal(result.total, 675710); assert.equal(result.complete, true); assert.equal(result.rows.length, 7);
});
test('honorários e extras de um veículo não vazam para o próximo', () => {
  normalizeInput({ plate: 'ERF9716', renavam: '250487675', fee: '130', transfer: '295', plateService: '200' });
  assert.deepEqual(normalizeInput({ plate: 'FOE4G55', renavam: '01026263821', fee: '100' }).extras, [{ id: 'honorarios', description: 'Honorários', cents: 10000 }]);
});
test('valores em centavos, formatos brasileiros e rejeição de entradas ambíguas', () => {
  assert.equal(cents('R$ 1.234,56'), 123456); assert.equal(cents('0,01') + cents('0,02'), 3); assert.equal(cents('100,5'), 10050);
  for (const value of ['100.50', '-10', '1e3', '1,999', '<script>', 'Infinity']) assert.throws(() => cents(value));
});
test('não assume honorários e aceita zero explícito', () => {
  assert.throws(() => normalizeInput({ plate: 'FOE4G55', renavam: '01026263821' }));
  assert.deepEqual(normalizeInput({ plate: 'FOE4G55', renavam: '01026263821', fee: '0' }).extras, []);
});
test('bloqueia identificação divergente ou leitura de outro veículo', () => {
  assert.equal(parseFazenda({ ...fiorino(), plate: 'ERF9716' }, input).status, 'pending');
  assert.equal(parseFazenda({ ...fiorino(), renavam: '250487675' }, input).rows.length, 0);
});
test('mudança de layout ou total divergente mantém subtotal', () => {
  assert.equal(parseFazenda({ ...fiorino(), totalText: 'R$ 6.700,00' }, input).status, 'pending');
  assert.equal(parseFazenda({ ...fiorino(), ipva: 'Saldo R$ 903,58' }, input).status, 'pending');
  assert.equal(parseFazenda({ ...fiorino(), finesPresent: false }, input).status, 'pending');
});
test('PGE nada consta só conclui com Renavam correto e envio confirmado', () => {
  assert.equal(parsePge({ noDebts: true, renavam: input.renavam }, input, false).status, 'pending');
  assert.equal(parsePge({ noDebts: true, renavam: '250487675' }, input, true).status, 'pending');
  assert.equal(parsePge({ noDebts: true, renavam: '1026263821' }, input, true).status, 'complete');
});
test('lista da PGE deduplica CDA e bloqueia conflitos ou paginação', () => {
  const row = { cda: '1491451634', type: 'IPVA', balance: 'R$ 2.674,41' };
  const data = { listPresent: true, rows: [row, row, { cda: '1443448290', type: 'IPVA', balance: 'R$ 3.026,47' }] };
  const pge = parsePge(data, input, true);
  assert.equal(pge.status, 'complete'); assert.equal(pge.rows.length, 2); assert.equal(pge.rows.reduce((a, b) => a + b.cents, 0), 570088);
  assert.equal(parsePge({ ...data, hasPagination: true }, input, true).status, 'pending');
  assert.equal(parsePge({ listPresent: true, rows: [row, { ...row, balance: 'R$ 2.600,00' }] }, input, true).status, 'pending');
});
test('consulta pendente nunca imprime TOTAL GERAL', () => {
  const state = { input, createdAt: '2026-09-24T14:00:00Z', fazenda: parseFazenda(fiorino(), input), pge: { status: 'pending', rows: [], message: 'Captcha pendente' } };
  assert.equal(quote(state).complete, false);
  assert.match(quoteText(state), /SUBTOTAL/); assert.doesNotMatch(quoteText(state), /TOTAL GERAL/); assert.match(quoteText(state), /Captcha pendente/);
});
test('linhas de exercícios anteriores entram uma vez e zeros são omitidos', () => {
  const f = fiorino(); f.priorText = '2025'; f.priorRows = [['2025','R$ 0,00','R$ 100,00','R$ 100,00']]; f.totalText = 'R$ 6.757,10';
  const parsed = parseFazenda(f, input); assert.equal(parsed.status, 'complete'); assert.equal(parsed.rows.filter(r => r.id === 'ipva-2025').length, 1);
  f.priorRows.push(['2024','R$ 0,00','R$ 0,00','R$ 0,00']);
  assert.equal(parseFazenda(f, input).rows.some(r => r.id === 'ipva-2024'), false);
});
test('múltiplos licenciamentos usam o valor a pagar, não somam a composição', () => {
  const f = fiorino(); f.licensing += '\nLicenciamento 2025 R$ 223,94 (1) Taxa Devida R$ 0,00 (2) Multa R$ 0,00 (3) Juros R$ 0,00 (4) Valor a Pagar (4)=(1)+(2)+(3) R$ 223,94'; f.totalText = 'R$ 6.881,04';
  const parsed = parseFazenda(f, input); assert.equal(parsed.status, 'complete'); assert.equal(parsed.rows.find(x => x.id === 'lic-2025').cents, 22394);
});
