const { test } = require('node:test');
const assert = require('node:assert/strict');
const vm = require('node:vm');
const fs = require('node:fs');
const domain = require('../domain');
const scripts = require('../portal-scripts');
const input = { plate: 'ABC1D23', renavam: '01234567890', extras: [] };
const heading = 'IPVA - Débitos de Exercícios Anteriores Inscritos em Dívida Ativa';
const snapshot = { plate: input.plate, renavam: input.renavam, activeDebtText: heading + '\nA existência de débitos em dívida ativa impede o licenciamento.\nNADA CONSTA' };
test('NADA CONSTA exige seção correta e identificação do veículo', () => {
  assert.equal(domain.activeDebtClear(snapshot, input), true);
  for (const change of [{ activeDebtText: 'Multas\nNADA CONSTA' }, { activeDebtText: heading }, { plate: 'DEF4G56' }, { renavam: '99999999999' }, { activeDebtText: snapshot.activeDebtText + '\nR$ 100,00' }]) assert.equal(domain.activeDebtClear({ ...snapshot, ...change }, input), false);
});
test('leitor restringe NADA CONSTA ao bloco de dívida ativa', () => {
  const body = {};
  const h = { innerText: heading };
  const section = { innerText: snapshot.activeDebtText, parentElement: body, querySelectorAll: () => [h] };
  h.parentElement = section;
  const doc = { body, querySelectorAll: () => [h] };
  assert.equal(vm.runInNewContext('(' + scripts.readActiveDebtSection.toString() + ')()', { document: doc }), snapshot.activeDebtText);
  section.querySelectorAll = () => [h, { innerText: 'Multas' }];
  assert.equal(vm.runInNewContext('(' + scripts.readActiveDebtSection.toString() + ')()', { document: doc }), '');
});
test('fluxo conclui pela Fazenda ou exige PGE, sem perder débitos já encontrados', async () => {
  const source = fs.readFileSync(require.resolve('../main'), 'utf8');
  const update = source.slice(source.indexOf('async function updatePortal('), source.indexOf('async function tick()'));
  for (const clear of [true, false]) {
    let opened = 0;
    const context = { state: { input, fazenda: { status: 'pending' }, pge: { status: 'pending', rows: [] } }, generation: 1,
      flow: { fazenda: {}, pge: {} }, portals: { fazenda: { isDestroyed: () => false, webContents: { isLoadingMainFrame: () => false } } },
      isPortalPage: () => true, scripts, domain: { ...domain, parseFazenda: () => ({ status: 'complete', rows: [] }) },
      execute: async () => ({ ...snapshot, activeDebtText: clear ? snapshot.activeDebtText : heading }),
      loadPortal: async () => { opened++; } };
    vm.createContext(context); vm.runInContext(update, context);
    await context.updatePortal('fazenda', 1);
    assert.equal(context.state.pge.status, clear ? 'complete' : 'pending');
    assert.equal(opened, clear ? 0 : 1);
    if (!clear) assert.match(context.state.pge.message, /obrigatória/);
  }
});
test('orçamento parcial não ganha TOTAL GERAL e conclusão informa a fonte', () => {
  const state = { input, createdAt: '2026-09-25T12:00:00Z', fazenda: { status: 'complete', rows: [] }, pge: { status: 'pending', rows: [], message: 'Consulta à PGE obrigatória' } };
  assert.doesNotMatch(domain.quoteText(state), /TOTAL GERAL/);
  assert.match(domain.quoteText(state), /obrigatória/);
  state.pge = { status: 'complete', source: 'Fazenda SP', rows: [] };
  assert.match(domain.quoteText(state), /NADA CONSTA na Fazenda SP/);
});
