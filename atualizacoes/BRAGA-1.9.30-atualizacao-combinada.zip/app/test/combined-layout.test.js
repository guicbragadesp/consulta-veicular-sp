const test=require('node:test'),assert=require('node:assert/strict');
const {quote}=require('../domain');
test('orçamento combinado mantém ordem dos serviços, soma e consulta Detran opcional',()=>{
 const state={fazenda:{status:'complete',rows:[{description:'Licenciamento',source:'fazenda',cents:200},{description:'IPVA',source:'fazenda',cents:300}]},pge:{status:'complete',rows:[]},input:{extras:[{id:'plateService',description:'Placa',cents:400},{id:'inspection',description:'Vistoria',cents:500},{id:'transfer',description:'Taxa de transferência',cents:600},{id:'honorarios',description:'Honorários',cents:700}]},detran:{status:'pending'}};
 const result=quote(state);
 assert.deepEqual(result.rows.map(row=>row.description),['IPVA','Licenciamento','Honorários','Taxa de transferência','Vistoria','Placa']);
 assert.equal(result.total,2700);assert.equal(result.complete,true);
});
