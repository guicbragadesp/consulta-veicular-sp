const { test } = require('node:test');
const assert = require('node:assert/strict');
const vm = require('node:vm');
const scripts = require('../portal-scripts');
function fixture(options = {}) {
  let clicks = 0;
  let paymentClicks = 0;
  const button = { innerText: 'Detalhamento', getAttribute: () => null, getClientRects: () => [1], click: () => clicks++ };
  const payment = { ...button, innerText: 'Pagar com Pix', click: () => paymentClicks++ };
  const body = {};
  const section = { parentElement: body, querySelectorAll: selector => selector === 'table' ? [{}] : selector.startsWith('h1') ? [{ innerText: 'Multas' }] : options.missing ? [payment] : options.ambiguous ? [button, button, payment] : [button, payment] };
  const ids = { placa_veiculo: { innerText: options.plate || 'ABC1D23' }, renavam_veiculo: { innerText: '01234567890' }, tableMultas: { parentElement: section } };
  const document = { body, getElementById: id => ids[id] };
  return { run: () => vm.runInNewContext(scripts.script(scripts.openFineDetails, { plate: 'ABC1D23', renavam: '1234567890' }), { document }), counts: () => [clicks, paymentClicks] };
}
test('detalhamento só é acionado sob demanda e não clica em pagamento', () => {
  const f = fixture(); assert.deepEqual(f.counts(), [0, 0]);
  assert.equal(f.run(), 'clicked'); assert.deepEqual(f.counts(), [1, 0]);
});
test('não abre multas de outro veículo', () => {
  const f = fixture({ plate: 'DEF4G56' }); assert.equal(f.run(), 'mismatch'); assert.deepEqual(f.counts(), [0, 0]);
});
test('botão ausente ou ambíguo não aciona outro serviço', () => {
  for (const option of [{ missing: true }, { ambiguous: true }]) {
    const f = fixture(option); assert.equal(f.run(), 'missing'); assert.deepEqual(f.counts(), [0, 0]);
  }
});
