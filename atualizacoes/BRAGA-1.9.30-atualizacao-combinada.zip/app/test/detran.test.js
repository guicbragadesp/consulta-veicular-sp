'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { parse } = require('../detran');
const { rowsFromText } = require('../detran');
test('lê texto visível da imagem do Detran quando seletores dos valores mudam', () => {
  const text = 'Restrições do veículo\nBloqueio de furto/roubo\nNada consta\nRestrição tributária\nNada consta\nRestrição financeira\nConsta Intenção de Gravame\nRestrição administrativa\nNada consta\nRestrição judicial\nNão Consta Bloqueio Judicial - Renajud\nRestrição por veículo guinchado\nNada consta';
  const result = parse({plate:'GIC5C05',renavam:'01163941570',fuel:'ALCOOL/GASOLINA',rows:rowsFromText(text)}, {plate:'GIC5C05',renavam:'01163941570'});
  assert.equal(result.status, 'complete');
  assert.equal(result.alerts.length, 1);
  assert.equal(result.alerts[0].value, 'Consta Intenção de Gravame');
  assert.equal(rowsFromText('Restrição financeira\n').length, 0);
});
const input = { plate: 'ABC1D23', renavam: '00123456789' };
const titles = ['Bloqueio de furto/roubo', 'Restrição tributária', 'Restrição financeira', 'Restrição administrativa', 'Restrição judicial', 'Restrição por veículo guinchado'];
const snapshot = () => ({ ...input, fuel: 'ALCOOL/GASOLINA', rows: titles.map(title => ({ title, value: title === 'Restrição judicial' ? 'Não Consta Bloqueio Judicial - Renajud' : 'Nada consta' })) });
test('script isolado lê cartões fora da seção antiga, com títulos capitalizados', () => {
  const vm = require('node:vm');
  const { snapshotPage } = require('../detran');
  const element = text => ({innerText:text,textContent:text,children:[],getClientRects:()=>[1]});
  const body = element('');
  const cards = snapshot().rows.map(row => {
    const title = row.title.replace(/\b\p{L}/gu, c => c.toUpperCase());
    const heading = element(title), value = element(row.title === titles[2] ? 'Consta Intenção de Gravame' : row.value);
    const card = element(title+'\n'+value.innerText);
    card.children=[heading,value];card.parentElement=body;heading.parentElement=card;value.parentElement=card;
    return [card,heading,value];
  }).flat();
  const label=element('Renavam'),fuel=element('Combustível');
  label.nextElementSibling=element(input.renavam);fuel.nextElementSibling=element('ALCOOL/GASOLINA');
  const vehicle=element('');vehicle.querySelectorAll=()=>[label,fuel];
  vehicle.querySelector=()=>({getAttribute:()=>input.plate});
  const document={body,getElementById:()=>vehicle,querySelector:()=>null,querySelectorAll:()=>cards};
  const result = parse(vm.runInNewContext('('+snapshotPage.toString()+')()', {document,getComputedStyle:()=>({visibility:'visible'})}),input);
  assert.equal(result.status,'complete');assert.equal(result.alerts.length,1);
  assert.equal(result.alerts[0].value,'Consta Intenção de Gravame');
  cards[8].innerText='';
  cards[6].innerText=cards[7].innerText;
  const partial=parse(vm.runInNewContext('('+snapshotPage.toString()+')()', {document,getComputedStyle:()=>({visibility:'visible'})}),input);
  assert.equal(partial.status,'pending');
});
test('seis categorias claras, inclusive a negativa judicial, não alertam', () => { const r = parse(snapshot(), input); assert.equal(r.status, 'complete'); assert.equal(r.alerts.length, 0); });
test('intenção de gravame e qualquer categoria positiva alertam', () => { for (let i = 0; i < titles.length; i++) { const s = snapshot(); s.rows[i].value = i === 2 ? 'Consta Intenção de Gravame' : 'Consta bloqueio'; assert.equal(parse(s,input).alerts[0].title, titles[i]); } });
test('não confunde outra placa nem outro Renavam com o veículo consultado', () => { for (const extra of [{plate:'XYZ9A99'}, {renavam:'99999999999'}]) { const r = parse({...snapshot(),...extra}, input); assert.equal(r.status,'pending'); assert.equal(r.rows.length,0); } });
test('resultado ausente, parcial e duplicado nunca confirma ausência de restrições', () => { assert.equal(parse(null,input).status,'pending'); const s=snapshot(); s.rows.pop(); assert.equal(parse(s,input).status,'pending'); s.rows=snapshot().rows; s.rows.push(s.rows[0]); assert.equal(parse(s,input).status,'pending'); });
test('mensagens desconhecidas e negativas ambíguas exigem conferência', () => { const s=snapshot(); s.rows[4].value='Não consta bloqueio judicial, mas consta outra restrição'; assert.equal(parse(s,input).alerts.length,1); s.rows[4].value='Serviço indisponível'; assert.equal(parse(s,input).alerts.length,1); });
test('compara identificadores com zeros e formatação e alerta categoria nova', () => { const s=snapshot(); s.plate='ABC-1D23'; s.renavam='123456789'; s.rows.push({title:'Restrição adicional',value:'Consta'}); const r=parse(s,input); assert.equal(r.status,'complete'); assert.equal(r.alerts.length,1); });
test('GNV isolado, combinado e gás natural veicular geram alerta', () => { for(const fuel of ['GNV','GASOLINA/GNV','ÁLCOOL / GNV','Gás Natural Veicular']) { const r=parse({...snapshot(),fuel},input);assert.equal(r.alerts.length,1);assert.equal(r.alerts[0].title,'Combustível'); } });
test('combustíveis comuns não alertam e combustível ausente mantém leitura pendente', () => { for(const fuel of ['GASOLINA','ALCOOL/GASOLINA','DIESEL','ELÉTRICO'])assert.equal(parse({...snapshot(),fuel},input).alerts.length,0);assert.equal(parse({...snapshot(),fuel:''},input).status,'pending'); });
test('combustível de outro veículo não gera alerta', () => { assert.equal(parse({...snapshot(),plate:'XYZ9A99',fuel:'GNV'},input).alerts.length,0); });
test('Detran opcional não impede orçamento, altera total nem exige consulta de restrições', () => {
  const domain = require('../domain');
  const state = { input: {...input,extras:[{description:'Honorários',cents:5000}]},fazenda:{status:'complete',rows:[{description:'IPVA',cents:10000}]},pge:{status:'complete',rows:[]} };
  for (const detran of [undefined,{status:'pending'}, {status:'complete',alerts:[{title:'Combustível',value:'GNV'}]}]) {
    const quote=domain.quote({...state,detran}); assert.equal(quote.complete,true);assert.equal(quote.total,15000);
  }
});
