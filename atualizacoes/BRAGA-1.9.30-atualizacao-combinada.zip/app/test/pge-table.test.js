'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const vm = require('node:vm');
const scripts = require('../portal-scripts');
const domain = require('../domain');
const header = ['CPF/CNPJ', 'IE', 'Nº de Registro/CDA', 'Referência', 'Data de Inscrição', 'Valor Atualizado (R$)', 'Opções de Pagamento', 'Observação'];
const debts = [['1428562980', '1.119,47'], ['1397626488', '1.223,21'], ['1369278062', '1.500,60'], ['1351304226', '1.723,59']];
const matrix = () => [header, ...debts.map(([cda, value]) => ['***', '', cda, '13/02/2025', '25/07/2025', value, 'Liquidar/ Pagamento Parcial/ Parcelar', 'Dados do Cartório']), ['Valor Total Atualizado (R$):', '5.566,87']];
const parse = tables => domain.parsePge(scripts.pgeTables(tables), { renavam: '283933437' }, true);
test('quatro CDAs da imagem: valores individuais e subtotal 5666,87', () => {
  const pge = parse([matrix()]);
  assert.equal(pge.status, 'complete');
  assert.deepEqual(pge.rows.map(r => r.cents), [111947, 122321, 150060, 172359]);
  const q = domain.quote({pge, fazenda: {status:'pending', rows:[]}, input:{extras:[{cents:10000}]}});
  assert.equal(q.total, 566687);
  assert.equal(q.complete, false);
});
test('CDA e tabela repetidas não duplicam valores', () => {
  const m = matrix(); m.splice(2, 0, m[1]);
  const pge = parse([m, matrix()]);
  assert.equal(pge.status, 'complete');
  assert.equal(pge.rows.length, 4);
});
test('total replicado, conflito ou valor ausente não entram no orçamento', () => {
  for (const kind of ['replicated', 'conflict', 'missing', 'total']) {
    const m = matrix();
    if (kind === 'replicated') for (let i=1;i<=4;i++) m[i][5] = '5.566,87';
    if (kind === 'conflict') m.splice(2,0,[...m[1].slice(0,5),'9,99','', '']);
    if (kind === 'missing') m[1][5] = '';
    if (kind === 'total') m.pop();
    const pge = parse([m]);
    assert.equal(pge.status, 'pending', kind);
    assert.deepEqual(pge.rows, [], kind);
  }
});
test('ordem de colunas diferente mantém CDA vinculada ao valor', () => {
  const m = matrix().map(row => row.length === 8 ? [row[5],row[2],...row.slice(0,2),...row.slice(3,5),...row.slice(6)] : row);
  assert.equal(parse([m]).status, 'complete');
});
test('script executado no portal usa o extrator e ignora tabela externa', () => {
  const nested = {getClientRects:()=>[1], rows:[]};
  const table = {getClientRects:()=>[1],querySelector:()=>nested,rows:[]};
  table.rows = matrix().map(row=>({closest:()=>table,cells:row.map(innerText=>({innerText}))}));
  table.rows[0].cells[5].innerText = 'Valor\nAtualizado (R$)';
  const outer = {getClientRects:()=>[1],querySelector:()=>table,rows:[]};
  outer.rows = [{closest:()=>outer,cells:[{innerText:'Resumo da página'}]}];
  const document = {
    body: { innerText: '' },
    querySelectorAll: selector => selector === 'table' ? [outer, table, nested] : [],
    querySelector:()=>null,
    getElementById: id => id.endsWith(':renavam') ? {value:'283933437'} : null
  };
  const snapshot = vm.runInNewContext(scripts.script(scripts.readPge), {document});
  const pge = domain.parsePge(snapshot,{renavam:'283933437'},true);
  assert.equal(pge.status,'complete');
  assert.equal(pge.rows.reduce((s,r)=>s+r.cents,0),556687);
  assert.equal(domain.parsePge(snapshot,{renavam:'999999999'},true).status,'pending');
});
