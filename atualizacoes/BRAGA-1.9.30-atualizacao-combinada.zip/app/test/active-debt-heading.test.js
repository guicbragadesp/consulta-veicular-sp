const { test } = require('node:test');
const assert = require('node:assert/strict');
const vm = require('node:vm');
const scripts = require('../portal-scripts');
const domain = require('../domain');
const title = 'IPVA - Débitos de Exercícios Anteriores Inscritos em Dívida Ativa';
function read(resultHeading, siblingHeading) {
  const body = {};
  const heading = { innerText: title };
  const result = { innerText: resultHeading };
  const section = { parentElement: body, innerText: title + '\nA existência de débitos em dívida ativa impede o licenciamento ou a transferência do veículo.\n' + resultHeading,
    querySelectorAll: () => [heading, result, ...(siblingHeading ? [{ innerText: siblingHeading }] : [])] };
  heading.parentElement = section;
  const document = { body, querySelectorAll: () => [heading, result] };
  return vm.runInNewContext(scripts.script(scripts.readActiveDebtSection), { document });
}
test('NADA CONSTA em título h3/h4 dentro do painel é aceito', () => {
  const activeDebtText = read('NADA CONSTA');
  assert.match(activeDebtText, /NADA CONSTA/);
  const input = { plate: 'ABC1D23', renavam: '01234567890' };
  assert.equal(domain.activeDebtClear({ ...input, activeDebtText }, input), true);
});
test('continua recusando NADA CONSTA encontrado junto de outro bloco', () => {
  assert.equal(read('NADA CONSTA', 'Multas'), '');
  assert.equal(read('NADA CONSTA', 'IPVA - Débitos de Exercícios Anteriores Não Inscritos em Dívida Ativa'), '');
});
