'use strict';

// Executadas apenas no documento principal dos endereços oficiais permitidos.
function readActiveDebtSection() {
  const normalize = value => String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, ' ').trim();
  const isHeading = value => /^IPVA\s*[-–—]\s*Debitos de Exercicios Anteriores Inscritos em Divida Ativa$/i.test(normalize(value));
  const selector = 'h2,h3,h4,h5,h6,.panel-heading,.card-header';
  const heading = [...document.querySelectorAll(selector)].find(el => isHeading(el.innerText));
  if (!heading) return '';
  for (let section = heading.parentElement; section && section !== document.body; section = section.parentElement) {
    // NADA CONSTA pode ser um h3/h4 dentro do próprio bloco, não outro bloco.
    if ([...section.querySelectorAll(selector)].some(el => { const label = normalize(el.innerText); return label && !isHeading(label) && !/^NADA CONSTA[.!]?$/i.test(label); })) return '';
    const text = section.innerText.trim();
    if (normalize(text) !== normalize(heading.innerText)) return text;
  }
  return '';
}
function readFazenda() {
  const byId = id => document.getElementById(id);
  const text = id => byId(id)?.innerText?.trim() || '';
  const table = id => [...(byId(id)?.querySelectorAll('tr') || [])].map(r => [...r.querySelectorAll('td')].map(c => c.innerText.trim()));
  const headings = [...document.querySelectorAll('h3,h4,h5')];
  return {
    activeDebtText: readActiveDebtSection(),
    plate: text('placa_veiculo'), renavam: text('renavam_veiculo'), model: text('marcaModelo'), year: text('anoFabricacao'),
    ipvaHeading: headings.find(x => /^IPVA\s+\d{4}/i.test(x.innerText.trim()))?.innerText || '', ipva: text('ipvaCollapse'),
    priorPresent: !!byId('tableDebitosAnterioresNaoInscritos'), priorText: text('tableDebitosAnterioresNaoInscritos'), priorRows: table('tableDebitosAnterioresNaoInscritos'),
    licensingPresent: !!byId('taxaLCollapse'), licensing: text('taxaLCollapse'),
    finesPresent: !!byId('tableMultas'), finesText: text('tableMultas'), fineRows: table('tableMultas'),
    totalText: headings.find(x => /Total de Débitos\s*\(exceto/i.test(x.innerText))?.innerText || '',
    formReady: !!byId('renavam') && !!byId('placa') && !!byId('consultar'),
    login: /Autenticação de usuário|Sessão expirada/i.test(document.body.innerText),
    loggedIn: !!document.querySelector('a[href*="/Logout"]'),
    message: [...document.querySelectorAll('.validation-summary-errors,.alert-danger')].map(x => x.innerText).join(' ')
  };
}
function fillFazenda(input) {
  const renavam = document.getElementById('renavam');
  const plate = document.getElementById('placa');
  const button = document.getElementById('consultar');
  if (!renavam || !plate || !button) return false;
  for (const [el, value] of [[renavam, input.renavam], [plate, input.plate]]) {
    el.value = value;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }
  button.click(); return true;
}
function selectFazendaGovLogin() {
  if (location.protocol !== 'https:' || location.hostname !== 'www3.fazenda.sp.gov.br') return 'blocked';
  const button = document.getElementById('loginPessoaFisicaLoginUnicoFederal');
  if (!button) return 'missing';
  const href = new URL(button.href, location.href);
  if (href.origin !== location.origin || href.pathname !== '/SIVEI/LoginSolicitantes/LoginPessoaFisicaLoginUnicoFederal') return 'blocked';
  if (button.dataset.bragaStarted) return 'already-started';
  const person = document.getElementById('opcaoPessoaFisica');
  if (person && !person.checked) person.click();
  button.dataset.bragaStarted = 'true';
  button.click();
  return 'clicked';
}
function fillGovLogin(credentials) {
  if (location.protocol !== 'https:' || location.hostname !== 'sso.acesso.gov.br') return 'blocked';
  const fields = [...document.querySelectorAll('input')].filter(el => !el.disabled && el.type !== 'hidden');
  const password = fields.find(el => el.type === 'password');
  const cpf = fields.find(el => /cpf|accountid|document/i.test((el.name || '') + ' ' + (el.id || '') + ' ' + (el.placeholder || '')));
  const target = password || cpf;
  if (!target) return 'waiting';
  if (!target.value) {
    target.value = password ? credentials.password : credentials.cpf;
    target.dispatchEvent(new Event('input', { bubbles: true }));
    target.dispatchEvent(new Event('change', { bubbles: true }));
  }
  if (password) {
    if (password.value !== credentials.password) return 'different-password';
    if (password.dataset?.bragaSubmitted) return 'already-submitted';
    const enter = [...document.querySelectorAll('button,input[type=submit]')].find(el =>
      /^Entrar$/i.test((el.innerText || el.value || '').trim()) && !el.disabled);
    if (!enter) return 'password-filled';
    if (password.dataset) password.dataset.bragaSubmitted = 'true';
    enter.click();
    return 'password-submitted';
  }
  if (String(cpf.value).replace(/\D/g, '') !== credentials.cpf) return 'different-cpf';
  if (cpf.dataset?.bragaContinued) return 'already-continued';
  const button = [...document.querySelectorAll('button,input[type=submit]')].find(el =>
    /^Continuar$/i.test((el.innerText || el.value || '').trim()) && !el.disabled);
  if (button) {
    if (cpf.dataset) cpf.dataset.bragaContinued = 'true';
    button.click();
    return 'cpf-continued';
  }
  return 'cpf-filled';
}
// Acionada exclusivamente pelo botão de detalhamento do aplicativo.
function openFineDetails(input) {
  const text = id => document.getElementById(id)?.innerText?.trim() || '';
  const plate = value => String(value).replace(/[\s-]/g, '').toUpperCase();
  const renavam = value => String(value).replace(/\D/g, '').replace(/^0+/, '');
  if (plate(text('placa_veiculo')) !== plate(input.plate) ||
      renavam(text('renavam_veiculo')) !== renavam(input.renavam)) return 'mismatch';
  const table = document.getElementById('tableMultas');
  if (!table) return 'missing';
  // Busca apenas no bloco de Multas, nunca em outros blocos ou pagamentos.
  for (let section = table.parentElement; section && section !== document.body; section = section.parentElement) {
    const headings = [...section.querySelectorAll('h1,h2,h3,h4,h5,h6,.panel-heading,.card-header')];
    if (!headings.some(el => /^Multas$/i.test(el.innerText.trim()))) continue;
    if (section.querySelectorAll('table').length !== 1) return 'missing';
    const buttons = [...section.querySelectorAll('a,button,input[type=button],input[type=submit]')]
      .filter(el => /^(Detalhamento|Detalhamento das multas)$/i.test((el.innerText || el.value || '').trim()) &&
        !el.disabled && el.getAttribute('aria-disabled') !== 'true' && el.getClientRects().length > 0);
    if (buttons.length !== 1) return 'missing';
    buttons[0].click();
    return 'clicked';
  }
  return 'missing';
}
function preparePge(input) {
  const typeSelect = document.getElementById('consultaDebitoForm:decLblTipoConsulta:opcoesPesquisa');
  if (typeSelect) {
    if (typeSelect.value !== 'RENAVAM') {
      typeSelect.value = 'RENAVAM';
      typeSelect.dispatchEvent(new Event('change', { bubbles: true }));
      return 'selecting';
    }
    const field = document.getElementById('consultaDebitoForm:decTxtTipoConsulta:renavam');
    if (!field) return 'waiting';
    field.value = input.renavam;
    field.dispatchEvent(new Event('input', { bubbles: true }));
    field.dispatchEvent(new Event('change', { bubbles: true }));
    return 'ready';
  }
  const renavamRadio = document.getElementById('adesaoForm:j_id83:2');
  if (renavamRadio && !renavamRadio.checked) { renavamRadio.click(); return 'selecting'; }
  const field = document.getElementById('adesaoForm:renavam');
  if (!field) return 'waiting';
  field.value = input.renavam;
  field.dispatchEvent(new Event('input', { bubbles: true }));
  field.dispatchEvent(new Event('change', { bubbles: true }));
  return 'ready';
}
// Read columns by their headings; never associate a page total with a CDA.
function pgeTables(tables) {
  const rows = [], totals = [], errors = [];
  const clean = value => String(value || '').replace(/\s+/g, ' ').trim();
  const amount = value => {
    const text = clean(value).replace(/^R\$\s*/, '');
    return /^(?:\d+|\d{1,3}(?:\.\d{3})+),\d{2}$/.test(text) ? 'R$ ' + text : '';
  };
  let listPresent = false;
  for (const matrix of tables) {
    const headerIndex = matrix.findIndex(cells =>
      cells.some(c => /CDA/i.test(c)) && cells.some(c => /^Valor Atualizado/i.test(clean(c))));
    if (headerIndex < 0) continue;
    listPresent = true;
    const headers = matrix[headerIndex].map(clean);
    const cdaIndex = headers.findIndex(c => /CDA/i.test(c));
    const valueIndex = headers.findIndex(c => /^Valor Atualizado/i.test(c));
    for (const cells of matrix.slice(headerIndex + 1)) {
      if (cells.some(c => /Valor Total Atualizado/i.test(c))) {
        const values = cells.map(amount).filter(Boolean);
        if (values.length === 1) totals.push(values[0]);
        else errors.push('Total da PGE não reconhecido.');
        continue;
      }
      if (!cells.some(c => clean(c))) continue;
      if (cells.some(c => /CDA/i.test(c)) && cells.some(c => /^Valor Atualizado/i.test(clean(c)))) continue;
      const cda = clean(cells[cdaIndex]);
      const balance = amount(cells[valueIndex]);
      if (!/^\d+$/.test(cda) || !balance) {
        errors.push('CDA ou valor da mesma linha não reconhecido.');
        continue;
      }
      rows.push({ cda, type: 'IPVA', balance });
    }
  }
  return { rows, totals, errors, listPresent, verifyTotal: true };
}
function readPge() {
  // Keep debt tables even when payment cells contain nested layout tables.
  // Only direct rows belong to each table; nested rows are read separately.
  const matrices = [...document.querySelectorAll('table')]
    .filter(t => t.getClientRects().length)
    .map(t => [...t.rows].filter(r => r.closest('table') === t)
      .map(r => [...r.cells].map(c => c.innerText.replace(/\s+/g, ' ').trim())));
  const result = pgeTables(matrices);
  const field = document.getElementById('consultaDebitoForm:decTxtTipoConsulta:renavam') ||
    document.getElementById('adesaoForm:renavam');
  const msg = document.getElementById('ajaxMessages')?.innerText || '';
  let detailOpening = false;
  if (!result.listPresent) {
    const link = [...document.querySelectorAll('a')].find(a =>
      /^IPVA$/i.test(a.innerText.trim()) && a.getClientRects().length);
    if (link && !link.dataset.codexDetailOpened) {
      link.dataset.codexDetailOpened = '1';
      link.click();
      detailOpening = true;
    }
  }
  return { ...result, detailOpening, renavam: field?.value || '',
    noDebts: /Não foram encontrados débitos|não possui débitos|nenhum débito encontrado|Nenhum resultado com os critérios de consulta/i.test(msg + ' ' + document.body.innerText),
    message: result.errors.join(' ') || (result.listPresent ? 'Conferindo CDAs e total da PGE.' : 'Aguardando a tabela detalhada das CDAs.'),
    resultPresent: result.listPresent,
    hasPagination: [...document.querySelectorAll('.rich-datascr, .rf-ds, .ui-paginator')].some(el => el.getClientRects().length),
    formReady: !!field,
    captchaReady: !!document.querySelector('[name="g-recaptcha-response"]')?.value?.trim() };
}
function submitPge(input) {
  const newField = document.getElementById('consultaDebitoForm:decTxtTipoConsulta:renavam');
  if (newField) {
    const norm = x => String(x).replace(/^0+/, '');
    if (norm(newField.value) !== norm(input.renavam)) return 'mismatch';
    const button = [...document.querySelectorAll('input[type=submit],input[type=button],button')].find(el => (el.value || el.innerText || '').trim() === 'Consultar');
    if (!button || button.disabled) return 'missing';
    button.click(); return 'clicked';
  }
  const field = document.getElementById('adesaoForm:renavam');
  const norm = x => String(x).replace(/^0+/, '');
  const selected = document.getElementById('adesaoForm:j_id83:2');
  if (!field || !selected?.checked || norm(field.value) !== norm(input.renavam)) return 'mismatch';
  const form = field.form;
  if (!form) return 'missing';
  const button = [...form.querySelectorAll('input[type=submit],input[type=button],button')].find(el => (el.value || el.innerText || '').trim() === 'Consultar');
  if (!button || button.disabled) return 'missing';
  // Preserva o submitter JSF, o ViewState e a resposta do captcha do próprio formulário.
  button.click(); return 'clicked';
}
function script(fn, arg) { return '(() => { const readActiveDebtSection = ' + readActiveDebtSection.toString() + '; const pgeTables = ' + pgeTables.toString() + '; return (' + fn.toString() + ')(' + (arg === undefined ? '' : JSON.stringify(arg)) + '); })()'; }
module.exports = { selectFazendaGovLogin, readActiveDebtSection, openFineDetails, fillGovLogin, readFazenda, fillFazenda, preparePge, readPge, submitPge, script, pgeTables };
