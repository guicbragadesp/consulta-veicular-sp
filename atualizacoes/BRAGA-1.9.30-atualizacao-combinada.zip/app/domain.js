'use strict';

// Dinheiro sempre em centavos inteiros: nunca somar números decimais de reais.
function cents(value) {
  let text = String(value ?? '').replace(/R\$/g, '').replace(/\s/g, '');
  if (!text) return 0;
  if (!/^(?:\d+|\d{1,3}(?:\.\d{3})+)(?:,\d{1,2})?$/.test(text)) {
    throw new Error('Informe valores como 100 ou 1.234,56.');
  }
  const [whole, part = ''] = text.replace(/\./g, '').split(',');
  const result = Number(whole) * 100 + Number(part.padEnd(2, '0'));
  if (!Number.isSafeInteger(result) || result > 10000000000) throw new Error('Valor fora do limite.');
  return result;
}
function money(value) {
  return (value / 100).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}
function currencyValues(text) {
  return [...String(text || '').matchAll(/R\$\s*([\d.]+,\d{2})/g)].map(m => cents(m[1]));
}
function normalizeRenavam(value) {
  return String(value || '').replace(/\D/g, '').replace(/^0+/, '') || '0';
}
function normalizeInput(input) {
  const plate = String(input.plate || '').toUpperCase().replace(/[\s-]/g, '');
  const renavam = String(input.renavam || '').replace(/[\s.-]/g, '');
  if (!/^[A-Z]{3}\d[A-Z\d]\d{2}$/.test(plate)) throw new Error('Confira a placa: use ABC1234 ou ABC1D23.');
  if (!/^\d{9,11}$/.test(renavam) || /^0+$/.test(renavam)) throw new Error('Informe um Renavam com 9 a 11 dígitos.');
  if (!String(input.fee ?? '').trim()) throw new Error('Informe os honorários. Use 0 se não houver cobrança.');
  const extras = [{ id: 'honorarios', description: 'Honorários', cents: cents(input.fee) }];
  for (const [key, description] of [['transfer', 'Taxa de transferência'], ['inspection', 'Vistoria'], ['plateService', 'Placa']]) {
    if (String(input[key] ?? '').trim()) extras.push({ id: key, description, cents: cents(input[key]) });
  }
  if (String(input.otherValue ?? '').trim()) {
    const description = String(input.otherLabel || '').trim();
    if (!description || description.length > 100) throw new Error('Informe a descrição do outro serviço (até 100 caracteres).');
    extras.push({ id: 'outro', description, cents: cents(input.otherValue) });
  }
  if (input.services !== undefined) {
    if (!Array.isArray(input.services) || input.services.length > 30) throw new Error('Adicione no máximo 30 serviços.');
    const names = {transfer:'Taxa de transferência',inspection:'Vistoria',plateService:'Placa',engine:'Cadastro de motor',chassis:'Regravação de chassi'};
    input.services.forEach((service,i)=>{
      if (!service || (!Object.hasOwn(names,service.type) && service.type !== 'other')) throw new Error('Selecione um serviço válido.');
      const description = service.type === 'other' ? String(service.description || '').trim() : names[service.type];
      if (!description || description.length > 100) throw new Error('Informe a descrição do serviço (até 100 caracteres).');
      if (!String(service.value ?? '').trim()) throw new Error('Informe o valor de '+description+' ou remova o serviço.');
      extras.push({id:'service-'+i,description,cents:cents(service.value)});
    });
  }
  return { plate, renavam, extras: extras.filter(x => x.cents > 0) };
}
function parseFazenda(snapshot, expected) {
  const errors = [];
  const plate = String(snapshot.plate || '').replace(/\s/g, '').toUpperCase();
  if (plate !== expected.plate || normalizeRenavam(snapshot.renavam) !== normalizeRenavam(expected.renavam)) {
    return { status: 'pending', message: 'Aguardando o resultado da placa e do Renavam desta consulta.', rows: [] };
  }
  const rows = [];
  const add = (id, description, amount) => { if (amount > 0) rows.push({ id, description, cents: amount, source: 'Fazenda SP' }); };
  const ipvaYear = String(snapshot.ipvaHeading || '').match(/\b(20\d{2})\b/)?.[1];
  const payable = String(snapshot.ipva || '').match(/\(10\)\s*Valor a pagar[\s\S]*?R\$\s*([\d.]+,\d{2})/i);
  if (!payable || !ipvaYear) errors.push('Não foi possível conferir o IPVA do exercício.');
  else add('ipva-' + ipvaYear, 'IPVA ' + ipvaYear + ' (com acréscimos, quando houver)', cents(payable[1]));
  if (!snapshot.priorPresent) errors.push('Seção de IPVA de exercícios anteriores não localizada.');
  else if (!/NADA CONSTA/i.test(snapshot.priorText || '')) {
    let count = 0;
    for (const cells of snapshot.priorRows || []) {
      if (!/^\s*\d{4}\s*$/.test(cells[0] || '')) continue;
      const vals = currencyValues(cells.at(-1));
      if (vals.length !== 1) { errors.push('Débito anterior com valor não reconhecido.'); continue; }
      count++; add('ipva-' + cells[0].trim(), 'IPVA ' + cells[0].trim() + ' — não inscrito em dívida ativa', vals[0]);
    }
    if (!count) errors.push('Não foi possível ler os débitos de exercícios anteriores.');
  }
  const lic = String(snapshot.licensing || '');
  const licenses = [...lic.matchAll(/Licenciamento\s+(\d{4})([\s\S]*?)(?=Licenciamento\s+\d{4}|$)/gi)];
  if (!snapshot.licensingPresent || (!licenses.length && !/NADA CONSTA/i.test(lic))) errors.push('Licenciamentos não reconhecidos.');
  const licenseIds = new Set();
  for (const match of licenses) {
    const id = 'lic-' + match[1];
    if (licenseIds.has(id)) { errors.push('Licenciamento repetido: confira o portal.'); continue; }
    licenseIds.add(id);
    const payableMatch = match[2].match(/\(4\)\s*Valor a Pagar[\s\S]*?R\$\s*([\d.]+,\d{2})/i);
    if (!payableMatch) { errors.push('Valor final de licenciamento não reconhecido.'); continue; }
    add(id, 'Licenciamento ' + match[1], cents(payableMatch[1]));
  }
  if (!snapshot.finesPresent) errors.push('Seção de multas não localizada.');
  else if (!/NADA CONSTA/i.test(snapshot.finesText || '')) {
    let count = 0;
    for (const cells of snapshot.fineRows || []) {
      if (cells.length < 3 || !/^\d+$/.test(String(cells[1] || '').trim())) continue;
      const values = currencyValues(cells.at(-1));
      if (values.length !== 1) { errors.push('Multa com valor não reconhecido.'); continue; }
      count++;
      add('multa-' + cells[0].trim(), 'Multas ' + cells[0].trim() + ' — ' + cells[1].trim(), values[0]);
    }
    if (!count && currencyValues(snapshot.finesText).some(x => x > 0)) errors.push('Não foi possível separar as multas.');
  }
  const dedup = new Map();
  for (const row of rows) {
    if (dedup.has(row.id)) errors.push('Item repetido na Fazenda: ' + row.description);
    else dedup.set(row.id, row);
  }
  const unique = [...dedup.values()];
  const sum = unique.reduce((a, b) => a + b.cents, 0);
  const totals = currencyValues(snapshot.totalText);
  if (totals.length !== 1 || totals[0] !== sum) errors.push('A soma dos itens não confere com o total da Fazenda.');
  if (!snapshot.model || !/^\d{4}$/.test(String(snapshot.year || '').trim())) errors.push('Modelo ou ano não reconhecido.');
  return { status: errors.length ? 'pending' : 'complete', message: errors.length ? [...new Set(errors)].join(' ') : 'Consulta conferida com o total do portal.', rows: unique, model: snapshot.model, year: snapshot.year, checkedAt: new Date().toISOString() };
}
function parsePge(snapshot, expected, queryVerified) {
  if (snapshot.renavam && normalizeRenavam(snapshot.renavam) !== normalizeRenavam(expected.renavam)) return { status: 'pending', rows: [], message: 'O Renavam da PGE não corresponde à consulta.' };
  if (!queryVerified) return { status: 'pending', rows: [], message: 'Aguardando a consulta deste Renavam na PGE.' };
  if (snapshot.detailOpening) return { status: 'pending', rows: [], message: 'Abrindo o próximo detalhamento da PGE…' };
  if (snapshot.noDebts && normalizeRenavam(snapshot.renavam) === normalizeRenavam(expected.renavam)) {
    return { status: 'complete', rows: [], message: 'Não foram encontrados débitos para este Renavam.', checkedAt: new Date().toISOString() };
  }
  if (!snapshot.listPresent) return { status: 'pending', rows: [], message: snapshot.message || 'Resolva o captcha na PGE e clique em Consultar.' };
  const rows = new Map();
  const errors = [...(snapshot.errors || [])];
  for (const item of snapshot.rows || []) {
    if (!/^\d+$/.test(item.cda || '') || !item.type || currencyValues(item.balance).length !== 1) {
      errors.push('Há uma linha da PGE que não foi reconhecida.'); continue;
    }
    const amount = currencyValues(item.balance)[0];
    const isCda = /^\d+$/.test(item.cda);
    const row = { id: 'pge-' + item.cda, description: isCda ? item.type + ' em dívida ativa — CDA ' + item.cda : item.type + ' em dívida ativa', cents: amount, source: 'PGE' };
    if (rows.has(row.id) && rows.get(row.id).cents !== amount) errors.push('A mesma CDA aparece com saldos diferentes.');
    rows.set(row.id, row);
  }
  if (!rows.size) errors.push('A lista da PGE está vazia, sem confirmação de ausência de débitos.');
  if (snapshot.verifyTotal) {
    const totals = [...new Set(snapshot.totals || [])];
    const sum = [...rows.values()].reduce((a, r) => a + r.cents, 0);
    if (totals.length !== 1 || currencyValues(totals[0]).length !== 1 || currencyValues(totals[0])[0] !== sum) {
      errors.push('A soma das CDAs não confere com o total da PGE.');
    }
    if (errors.length) return { status: 'pending', rows: [], message: [...new Set(errors)].join(' ') };
  }
  if (snapshot.hasPagination) errors.push('A PGE tem mais páginas. A conferência completa precisa ser feita no portal.');
  return { status: errors.length ? 'pending' : 'complete', message: errors.length ? errors.join(' ') : 'Saldos da PGE conferidos por CDA.', rows: [...rows.values()].filter(x => x.cents > 0), checkedAt: new Date().toISOString() };
}
function activeDebtClear(snapshot, input) {
  if (String(snapshot.plate || '').replace(/[\s-]/g, '').toUpperCase() !== input.plate || normalizeRenavam(snapshot.renavam) !== normalizeRenavam(input.renavam)) return false;
  const text = String(snapshot.activeDebtText || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  const lines = text.split(/\r?\n/).map(line => line.replace(/\s+/g, ' ').trim()).filter(Boolean);
  return lines.some(line => /^NADA CONSTA[.!]?$/i.test(line)) &&
    /IPVA\s*[-–—]\s*Debitos de Exercicios Anteriores Inscritos em Divida Ativa/i.test(text) &&
    !currencyValues(text).some(value => value > 0);
}
function quote(state) {
  const rows = require('./quote-layout').rows(state);
  const complete = state.fazenda?.status === 'complete' && state.pge?.status === 'complete';
  return { rows, complete, total: rows.reduce((a, b) => a + b.cents, 0), pgeIgnored: !!state.pge?.ignored };
}
function quoteText(state) {
  const q = quote(state);
  return [
    '*ORÇAMENTO VEICULAR*', '',
    '*Placa:* ' + state.input.plate,
    'Renavam: ' + state.input.renavam,
    'Modelo: ' + (state.fazenda?.model || 'Aguardando consulta'),
    'Ano de fabricação: ' + (state.fazenda?.year || 'Aguardando consulta'), '',
    ...q.rows.map(x => '• ' + x.description + ': ' + money(x.cents)), '',
    '*' + (q.complete ? 'TOTAL GERAL: ' : 'SUBTOTAL: ') + money(q.total) + '*',
    ...(!q.complete ? ['', '*Orçamento parcial — consulta pendente*', ...['fazenda', 'pge'].filter(k => state[k]?.status !== 'complete').map(k => (k === 'fazenda' ? 'Fazenda SP' : 'PGE') + ': ' + state[k]?.message)] : []),
    ...(state.pge?.source === 'Fazenda SP' ? ['', 'IPVA em dívida ativa: NADA CONSTA na Fazenda SP.'] : []),
    '', 'Consulta em ' + new Date(state.createdAt).toLocaleString('pt-BR'),
    ...(q.rows.some(x => x.source === 'PGE') ? ['Dívida ativa: valores conforme os saldos exibidos na consulta da PGE.'] : [])
  ].join('\n');
}
module.exports = { activeDebtClear, cents, money, currencyValues, normalizeRenavam, normalizeInput, parseFazenda, parsePge, quote, quoteText };

