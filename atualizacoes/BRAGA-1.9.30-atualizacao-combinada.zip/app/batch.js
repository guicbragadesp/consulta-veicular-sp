'use strict';
const domain = require('./domain');
function parse(text, mode, fee) {
  const lines = String(text).trim().split(/\r?\n/).filter(x => x.trim());
  if (!lines.length || lines.length > 500) throw new Error('Informe de 1 a 500 veículos.');
  const seen = new Set();
  return lines.map((line, i) => {
    const cells = line.trim().split(/[;\t]/).map(s => s.trim());
    if (cells.length !== (mode === 'individual' ? 3 : 2)) throw new Error('Linha ' + (i + 1) + ': use placa;Renavam' + (mode === 'individual' ? ';honorários' : '') + '.');
    let input;
    try { input = domain.normalizeInput({ plate: cells[0], renavam: cells[1], fee: mode === 'none' ? '0' : mode === 'individual' ? cells[2] : fee }); }
    catch (e) { throw new Error('Linha ' + (i + 1) + ': ' + e.message); }
    if (seen.has(input.plate)) throw new Error('Placa repetida na linha ' + (i + 1) + ': ' + input.plate);
    seen.add(input.plate);
    return input;
  });
}
function report(batch) {
  const cards = [], boldRows = [], pdfSummaries = [];
  const summary = [['Placa','Renavam','Modelo','Ano','Situação','Fazenda','PGE','Subtotal apurado (R$)','Total confirmado (R$)','Pendências','Consulta iniciada']];
  const details = [['Placa','Renavam','Origem','Descrição','Valor (R$)','Situação']];
  batch.inputs.forEach((input, i) => {
    const state = batch.results[i];
    const q = state ? domain.quote(state) : { rows: [], total: 0, complete: false };
    const officialRows=state?.fazenda?.rows || [];
    pdfSummaries.push({licensing:officialRows.filter(r=>String(r.id||'').startsWith('lic-')).reduce((sum,r)=>sum+r.cents,0),fines:officialRows.filter(r=>String(r.id||'').startsWith('multa-')).reduce((sum,r)=>sum+r.cents,0),pending:state?.fazenda?.status!=='complete'});
    const status = !state ? 'Não consultado' : q.complete ? 'Concluído' : 'Pendente';
    const pending = state ? ['fazenda','pge'].filter(k => state[k]?.status !== 'complete').map(k => k + ': ' + (state[k]?.message || 'Pendente')).join(' | ') : 'Consulta não realizada';
    boldRows.push(cards.length);
    cards.push(['PLACA: ' + input.plate, status]);
    cards.push(['Renavam', input.renavam]);
    cards.push(['Modelo / ano', (state?.fazenda?.model || 'Não identificado') + ' / ' + (state?.fazenda?.year || '—')]);
    boldRows.push(cards.length);
    cards.push(['Descrição', 'Valor (R$)']);
    q.rows.forEach(row => { if(require('./quote-layout').extra(row)) boldRows.push(cards.length); cards.push([row.description, row.cents / 100]); });
    if (!q.rows.length) cards.push([q.complete ? 'Nenhum valor a cobrar' : 'Aguardando apuração', '']);
    boldRows.push(cards.length);
    cards.push([q.complete ? 'TOTAL GERAL (R$)' : 'SUBTOTAL APURADO (R$)', state ? q.total / 100 : '']);
    if (!q.complete) cards.push(['PENDÊNCIA', pending]);
    cards.push(['Consulta', state?.createdAt || 'Não realizada']);
    cards.push(['', '']); cards.push(['', '']);
    summary.push([input.plate, input.renavam, state?.fazenda?.model || '', state?.fazenda?.year || '', status, state?.fazenda?.status === 'complete' ? 'Concluída' : 'Pendente', state?.pge?.status === 'complete' ? 'Concluída' : 'Pendente', state ? q.total / 100 : '', q.complete ? q.total / 100 : '', pending, state?.createdAt || '']);
    q.rows.forEach(row => details.push([input.plate,input.renavam,row.source || 'Serviços',row.description,row.cents / 100,status]));
  });
  const cardSheet = { name: 'Quadros por placa', rows: cards, cards: true, boldRows, pdfSummaries, widths: [54, 24] };
  return [cardSheet, { name: 'Resumo por veículo', rows: summary }, { name: 'Débitos discriminados', rows: details }, printSheet(cardSheet)];
}
function printSheet(source) {
  return { name: 'Versão para impressão', cards: true, printLayout: true, widths: [54,24],
    rows: [['ORÇAMENTOS VEICULARES',''],['',''], ...source.rows.map(row=>[...row])],
    boldRows: [0,...source.boldRows.map(index=>index+2)] };
}
function parseFields({ plates, renavams, fee, transfer, inspection, plateService, otherLabel, otherValue }) {
  const p = String(plates || '').trim().split(/\r?\n/);
  const r = String(renavams || '').trim().split(/\r?\n/);
  if (!p[0] || p.length !== r.length) throw new Error('Informe a mesma quantidade de placas e Renavams, um por linha.');
  if (p.some(x => !x.trim()) || r.some(x => !x.trim())) throw new Error('Remova linhas vazias para manter cada placa junto ao Renavam correto.');
  const base = parse(p.map((plate,i) => plate.trim() + ';' + r[i].trim()).join('\n'), 'common', fee);
  return base.map(input => domain.normalizeInput({ plate: input.plate, renavam: input.renavam, fee, transfer, inspection, plateService, otherLabel, otherValue }));
}
function updateFee(batch, value) {
  if (!String(value ?? '').trim()) throw new Error('Informe os honorários. Use 0 se não cobrar.');
  const amount = domain.cents(value);
  const update = input => { input.extras = input.extras.filter(r => r.id !== 'honorarios'); if (amount > 0) input.extras.unshift({id:'honorarios',description:'Honorários',cents:amount}); };
  batch.inputs.forEach(update);
  batch.results.forEach(state => { if(state) update(state.input); });
  return amount;
}
module.exports = { parse, parseFields, report, updateFee, printSheet };

