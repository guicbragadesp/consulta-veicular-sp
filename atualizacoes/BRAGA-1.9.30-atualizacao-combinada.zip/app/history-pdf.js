'use strict';
const escape = value => String(value ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function html(sheet) {
  const blocks=[]; let rows=[], vehicleIndex=-1, summary=null, identityRows=new Set();
  function flush(){if(rows.length){
    if(summary){
      rows.push('<tr class="strong pdf-summary"><td colspan="2">Resumo de multas e licenciamento'+(summary.pending?' — valores parciais':'')+'</td></tr>');
      for(const [label,value] of [['Total das multas',summary.fines],['Total dos licenciamentos',summary.licensing]]) if(value>0) rows.push('<tr class="pdf-summary"><td>'+label+'</td><td>'+escape((value/100).toLocaleString('pt-BR',{style:'currency',currency:'BRL'}))+'</td></tr>');
      rows.push('<tr class="pdf-summary"><td colspan="2">Resumo informativo: valores já incluídos no orçamento, sem acréscimo ao total.</td></tr>');
    }
    blocks.push('<table>'+rows.join('')+'</table>');rows=[];summary=null;
  }}
  sheet.rows.forEach((row,index)=>{
    const title=String(row[0]||'');
    if(title.startsWith('PLACA:') || /^(SUB)?TOTAL DAS PLACAS/.test(title))flush();
    if(row.every(v=>v===''||v==null))return;
    if(title.startsWith('PLACA:')) {
      vehicleIndex++; const item=sheet.pdfSummaries?.[vehicleIndex]; summary=item&&(item.fines>0||item.licensing>0)?item:null;
      const identity = {};
      for(let next=index+1; next<sheet.rows.length; next++) {
        const label=String(sheet.rows[next][0]||'');
        if(label!=='Renavam' && label!=='Modelo / ano') break;
        identity[label]=String(sheet.rows[next][1]||''); identityRows.add(next);
      }
      const modelYear=identity['Modelo / ano']||'Não identificado / —';
      const separator=modelYear.lastIndexOf(' / ');
      const model=separator<0?modelYear:modelYear.slice(0,separator);
      const year=separator<0?'—':modelYear.slice(separator+3);
      rows.push('<tr class="identity"><td colspan="2"><div class="vehicle-header"><div class="plate" aria-label="'+escape(title)+'"><div class="band">BRASIL</div><div class="number">'+escape(title.slice(6).trim())+'</div></div><div class="vehicle-info"><div class="vehicle-model">'+escape(model)+'</div><div>Ano de fabricação: '+escape(year)+'</div><div class="vehicle-renavam">Renavam '+escape(identity.Renavam||'—')+'</div></div></div></td></tr>');
      return;
    }
    if(identityRows.has(index)) return;
    if(title === 'Consulta' && typeof row[1] === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(row[1])) {
      const date = new Date(row[1]);
      if (!Number.isNaN(date.getTime())) {
        const options = { timeZone: 'America/Sao_Paulo' };
        row = [row[0], date.toLocaleDateString('pt-BR', options) + ' às ' + date.toLocaleTimeString('pt-BR', { ...options, hour: '2-digit', minute: '2-digit', hourCycle: 'h23' })];
      }
    }
    const additional=/^(Taxa de transferência|Vistoria|Placa|Cadastro de motor|Regravação de chassi|Outro serviço)$/i.test(title);
    const total=/^(TOTAL GERAL|SUBTOTAL)(?:\b|\s)/i.test(title);
    const bold=sheet.boldRows.includes(index) || title==='Renavam' || title==='Modelo / ano';
    const classes=[bold?'strong':'',additional?'additional':'',total?'grand-total':''].filter(Boolean).join(' ');
    const label=title;
    rows.push('<tr'+(classes?' class="'+classes+'"':'')+'>'+row.map((v,i)=>'<td>'+(total && i===1 ? '<span class="total-arrow">➜</span> ' : '')+escape(typeof v==='number'?v.toLocaleString('pt-BR',{style:'currency',currency:'BRL'}):(i===0&&total?label:v))+'</td>').join('')+'</tr>');
  });flush();
  return '<!doctype html><html lang="pt-BR"><meta charset="utf-8"><title>Orçamento veicular</title><style>@page{size:A4;margin:12mm}body{font:10pt Arial;color:#111}h1{font-size:16pt}.plate{display:inline-block;border:2px solid #222;border-radius:5px;text-align:center;background:white;min-width:145px;color:#111}.band{background:#164596;color:white;font:bold 8pt Arial;letter-spacing:2px;padding:3pt}.number{font:bold 22pt monospace;letter-spacing:2px;padding:5pt 9pt}.identity td{background:white;vertical-align:middle;border:0;padding:0 0 15pt;text-align:left!important}.vehicle-header{display:flex;align-items:center;gap:12pt}.vehicle-info{min-width:0;font-size:8pt;color:#64748b;line-height:1.8;overflow-wrap:anywhere}.vehicle-renavam{font-size:10pt;font-weight:bold;color:#142c40}.vehicle-model{font-size:10pt;font-weight:bold;color:#142c40;line-height:1.3;margin-bottom:4pt}.plate{flex-shrink:0}.strong td{font-size:11pt}table{border-collapse:collapse;width:100%;margin:0 0 14pt;break-inside:avoid}td{border:1px solid #aaa;padding:6pt;overflow-wrap:anywhere}td:first-child{width:73%}td:last-child{text-align:right}tr{break-inside:avoid}.strong{font-weight:bold;background:#eee}.additional{background:#f7fbff}.additional td{font-weight:bold}.grand-total{background:white;color:#111;border:2px solid #aaa}.total-arrow{color:#0f766e}.grand-total td:last-child{white-space:nowrap}.grand-total td{font-size:14pt;font-weight:800;padding:9pt}.pdf-summary td{font-size:8pt;padding:4pt}</style><h1>Orçamento</h1>'+blocks.join('')+'</html>';
}
module.exports={html};

