'use strict';
const { ipcRenderer } = require('electron');

function identifySubmission(event) {
  const host = location.hostname;
  if (host !== 'www.dividaativa.pge.sp.gov.br') return;
  const element = event.target?.closest?.('button,input[type=submit],input[type=button],a');
  if (event.type === 'click' && (element?.value || element?.textContent || '').trim() !== 'Consultar') return;
  const field = document.getElementById('consultaDebitoForm:decTxtTipoConsulta:renavam') || document.getElementById('adesaoForm:renavam');
  const newSelect = document.getElementById('consultaDebitoForm:decLblTipoConsulta:opcoesPesquisa');
  const renavamSelected = document.getElementById('adesaoForm:j_id83:2')?.checked;
  ipcRenderer.send('portal:query', { renavam: field && (newSelect?.value === 'RENAVAM' || renavamSelected) ? field.value : '' });
}
// O reCAPTCHA roda em um iframe separado; o clique não borbulha para a página
// da PGE. Avisamos apenas que houve interação manual, sem ler o token.
if (/google\.com$|recaptcha/i.test(location.hostname + location.pathname)) {
  window.addEventListener('click', () => ipcRenderer.send('portal:captcha-interaction'), true);
}
window.addEventListener('click', event => {
  const el = event.target?.closest?.('button,input[type=submit],input[type=button],a');
  const label = (el?.value || el?.textContent || '').trim();
  if (/^(Pagar com Pix|Gerar GARE de Liquidação)$/i.test(label)) {
    event.preventDefault(); event.stopImmediatePropagation();
    ipcRenderer.send('portal:payment-blocked');
    return;
  }
  identifySubmission(event);
}, true);
window.addEventListener('submit', identifySubmission, true);

// Fecha somente o aviso informativo sobre os níveis da conta gov.br no SIVEI.
function continueFazendaNotice() {
  if (location.protocol !== 'https:' || location.hostname !== 'www3.fazenda.sp.gov.br' ||
      !/^\/SIVEI(?:\/|$)/i.test(location.pathname)) return;
  const normalize = value => String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, ' ').trim();
  const visible = element => element.getClientRects().length > 0 &&
    getComputedStyle(element).visibility !== 'hidden' && getComputedStyle(element).display !== 'none';
  for (const modal of document.querySelectorAll('.modal,[role="dialog"],.bootbox')) {
    if (!visible(modal)) continue;
    const text = normalize(modal.innerText);
    if (!/\bALERTA\b/i.test(text) || !/acesso ao SIVEI/i.test(text) ||
        !/nivel BRONZE/i.test(text) || !/PRATA OU OURO/i.test(text) ||
        !/certificacao digital/i.test(text)) continue;
    const buttons = [...modal.querySelectorAll('button,a,input[type="button"],input[type="submit"]')]
      .filter(el => /^Continuar$/i.test(normalize(el.innerText || el.value)) &&
        !el.disabled && el.getAttribute('aria-disabled') !== 'true' && visible(el));
    if (buttons.length !== 1) continue;
    const button = buttons[0];
    const now = Date.now();
    if (now - Number(button.dataset.bragaNoticeClick || 0) < 5000) continue;
    button.dataset.bragaNoticeClick = String(now);
    button.click();
    return;
  }
}
if (location.protocol === 'https:' && location.hostname === 'www3.fazenda.sp.gov.br') {
  let noticeTimer;
  const scheduleNotice = () => {
    clearTimeout(noticeTimer);
    noticeTimer = setTimeout(continueFazendaNotice, 150);
  };
  window.addEventListener('DOMContentLoaded', () => {
    new MutationObserver(scheduleNotice).observe(document.documentElement, {
      childList: true, subtree: true, attributes: true, attributeFilter: ['class', 'style', 'disabled']
    });
    scheduleNotice();
  }, { once: true });
}

