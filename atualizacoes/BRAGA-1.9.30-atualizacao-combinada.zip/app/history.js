'use strict';
const fs = require('node:fs');
const domain = require('./domain');
function createHistory(file) {
  let records = {};
  try { records = JSON.parse(fs.readFileSync(file, 'utf8')); if (!records || Array.isArray(records) || typeof records !== 'object') throw new Error('Histórico inválido'); }
  catch (error) { if (error.code !== 'ENOENT') throw new Error('Não foi possível ler o histórico salvo. O arquivo foi preservado.'); }
  const key = state => state.createdAt + '|' + state.input.plate + '|' + state.input.renavam;
  return {
    save(state) {
      if (!state?.input || !state.createdAt) return;
      const id = key(state), serialized = JSON.stringify(state);
      // Tombstones prevent an active query or saved batch from restoring a deletion.
      if (Object.hasOwn(records, id) && records[id] === null) return false;
      if (JSON.stringify(records[id]) === serialized) return false;
      const next = { ...records, [id]: JSON.parse(serialized) };
      fs.writeFileSync(file + '.tmp', JSON.stringify(next));
      fs.renameSync(file + '.tmp', file);
      records = next;
      return true;
    },
    list() {
      return Object.entries(records).filter(([,state]) => state !== null).map(([id,state]) => { const q = domain.quote(state); return { id, plate: state.input.plate, renavam: state.input.renavam, model: state.fazenda?.model || '', createdAt: state.createdAt, complete: q.complete, total: q.total }; }).sort((a,b) => b.createdAt.localeCompare(a.createdAt));
    },
    get(id) { if (!Object.hasOwn(records,id) || records[id] === null) throw new Error('Consulta não encontrada.'); return JSON.parse(JSON.stringify(records[id])); },
    remove(id) {
      if (!Object.hasOwn(records,id) || records[id] === null) throw new Error('Consulta não encontrada.');
      const next = { ...records, [id]: null };
      fs.writeFileSync(file + '.tmp', JSON.stringify(next));
      fs.renameSync(file + '.tmp', file);
      records = next;
    }
  };
}
module.exports = { createHistory };

