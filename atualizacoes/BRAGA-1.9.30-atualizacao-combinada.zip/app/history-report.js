'use strict';
const domain = require('./domain');
const batch = require('./batch');
function report(store, ids) {
  if (!Array.isArray(ids) || !ids.length || ids.length > 500 || ids.some(id => typeof id !== 'string')) throw new Error('Selecione de 1 a 500 consultas do histórico.');
  const results = [...new Set(ids)].map(id => store.get(id));
  const plates = new Set();
  for (const result of results) {
    if (plates.has(result.input.plate)) throw new Error('Selecione somente uma pesquisa por placa para não duplicar os valores: ' + result.input.plate);
    plates.add(result.input.plate);
  }
  const sheets = batch.report({ inputs: results.map(s => s.input), results });
  const quotes = results.map(domain.quote);
  const total = quotes.reduce((sum,q) => sum + q.total, 0);
  const complete = quotes.every(q => q.complete);
  const label = complete ? 'TOTAL DAS PLACAS SELECIONADAS (R$)' : 'SUBTOTAL DAS PLACAS SELECIONADAS (R$)';
  sheets[0].boldRows.push(sheets[0].rows.length);
  sheets[0].rows.push([label, total / 100]);
  if (!complete) sheets[0].rows.push(['ATENÇÃO', 'Há consultas pendentes. A soma é parcial.']);
  sheets[1].rows.push([label,'','','',complete?'Concluído':'Pendente','','',total/100,complete?total/100:'',complete?'':'Soma parcial: há consultas pendentes.','']);
  sheets[3] = batch.printSheet(sheets[0]);
  return sheets;
}
module.exports = { report };

