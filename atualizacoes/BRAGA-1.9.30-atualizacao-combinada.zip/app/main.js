'use strict';
const { app, BrowserWindow, ipcMain, clipboard, session, Menu, safeStorage } = require('electron');
const path = require('node:path');
const updater = require('./updater');
const { dialog, shell, nativeImage } = require('electron');
const { spawn } = require('node:child_process');
let updating = false;
const credentialFile = () => path.join(app.getPath('userData'), 'fazenda-login.bin');
const credentialsStore = require('./credentials');
let credentialVault;
function getCredentialVault() {
  if (!credentialVault) credentialVault = require('./credential-vault').createVault(credentialFile(), safeStorage);
  return credentialVault;
}
async function readCredential() { return getCredentialVault().active(); }
const fs = require('node:fs');
const domain = require('./domain');
const scripts = require('./portal-scripts');
const detran = require('./detran');
let detranController;
function getDetran() {
  if (!detranController) detranController = detran.createController({ BrowserWindow, navigationGuard, getCredential: readCredential, icon: path.join(__dirname, 'braga-app.ico'), onResult: result => {
    if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send('detran:changed', result);
  } });
  return detranController;
}
const { allowedNavigation, navigationGuard, pgeSubmission, shouldAutoSubmit } = require('./portal-flow');
// O aplicativo só renderiza formulários e tabelas; dispensa aceleração da GPU.
app.disableHardwareAcceleration();
const FAZENDA = 'https://www3.fazenda.sp.gov.br/SIVEI/DebitosVinculados/Consulta';
const PGE = 'https://www.dividaativa.pge.sp.gov.br/sc/pages/consultas/consultarDebito.jsf';
const HOSTS = { fazenda: 'www3.fazenda.sp.gov.br', pge: 'www.dividaativa.pge.sp.gov.br' };
const dataDir = path.resolve(__dirname, '..', 'dados');
fs.mkdirSync(dataDir, { recursive: true });
app.setPath('userData', dataDir);
const batchTools = require('./batch');
const xlsx = require('./xlsx');
const batchFile = path.join(dataDir, 'ultimo-lote.json');
let batch = null;
try { batch = JSON.parse(fs.readFileSync(batchFile, 'utf8')); if (batch) batch.running = false; } catch {}
function saveBatch() {
  if (!batch) return;
  fs.writeFileSync(batchFile + '.tmp', JSON.stringify(batch));
  fs.renameSync(batchFile + '.tmp', batchFile);
}
function batchView() {
  if (!batch) return null;
  return { ...batch, results: batch.results.map((r,i) => r || null), current: state && batch.running ? state : null };
}
function emitBatch() {
  if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send('batch:changed', batchView());
}
function resetPortals() {
  if (detranController) detranController.reset();
  generation++;
  for (const name of Object.keys(portals)) {
    if (portals[name] && !portals[name].isDestroyed()) portals[name].destroy();
    portals[name] = null; flow[name] = {};
  }
}
function startBatchVehicle() {
  saveHistory();
  resetPortals();
  if (batch.index >= batch.inputs.length) {
    batch.running = false; saveBatch(); emitBatch(); return;
  }
  const token = generation;
  state = { input: batch.inputs[batch.index], createdAt: new Date().toISOString(), fazenda: pending('Abrindo a Fazenda SP…'), pge: pending('Aguardando a Fazenda SP.') };
  emit(); emitBatch();
  void loadPortal('fazenda', token).then(() => tick());
}
function finishBatchVehicle(skip = false) {
  if (!batch?.running || !state) return;
  if (!skip && !domain.quote(state).complete) return;
  batch.results[batch.index] = JSON.parse(JSON.stringify(state));
  batch.index++; saveBatch(); startBatchVehicle();
}

let historyStore;
function getHistory() {
  if (!historyStore) {
    historyStore = require('./history').createHistory(path.join(dataDir, 'historico-consultas.json'));
    for (const result of batch?.results || []) if (result) historyStore.save(result);
  }
  return historyStore;
}
function saveHistory() {
  if (!state) return;
  try { const changed = getHistory().save(state); if (changed && mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send('history:changed', getHistory().list()); }
  catch (error) { if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send('history:error', error.message); }
}
let mainWindow;
let state = null;
let generation = 0;
let busy = false;
let poll;
const portals = { fazenda: null, pge: null };
const flow = { fazenda: {}, pge: {} };
const urls = { fazenda: FAZENDA, pge: PGE };

function emit() { saveHistory(); if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send('quote:changed', state); if (batch?.running) emitBatch(); }
function pending(message) { return { status: 'pending', message, rows: [] }; }
function trusted(event) {
  if (!mainWindow || event.sender !== mainWindow.webContents || event.senderFrame !== mainWindow.webContents.mainFrame) throw new Error('Origem não permitida.');
}
async function checkForUpdate(automatic = false) {
    if (updating) return 'Já existe uma verificação em andamento.';
    updating = true;
    try {
      const update = await updater.check(require('./package.json').version);
      if (!update) return 'Você já está usando a versão mais recente.';
      const choice = await dialog.showMessageBox(mainWindow, { type: 'info', title: 'Atualização disponível', message: 'Versão ' + update.version + ' disponível.', detail: 'O que há de novo?\n\n• Leitura da PGE reconhece quando não há resultado e conclui a pesquisa.\n• Orçamento fecha com total quando a Fazenda e a PGE forem concluídas.\n• Consulta opcional da PGE mantém o Renavam preenchido e evita duplicação de débitos.\n• Renavam destacado no orçamento e no PDF.\n\nDeseja baixar e abrir o instalador? O programa será fechado. Copie o orçamento antes de atualizar. Seus dados e logins salvos serão mantidos.', buttons: ['Baixar e atualizar', 'Agora não'], defaultId: 0, cancelId: 1 });
      if (choice.response !== 0) return 'Atualização adiada.';
      const file = await updater.download(update, app.getPath('temp'));
      const child = spawn(file, ['/SP-', '/DIR=' + path.resolve(__dirname, '..')], { detached: true, stdio: 'ignore', windowsHide: false });
      await new Promise((resolve, reject) => { child.once('spawn', resolve); child.once('error', reject); });
      child.unref();
      app.quit();
      return 'Instalador aberto.';
    } catch (error) {
      if (automatic) return;
      if (/fetch|network|timeout|abort/i.test(error.message || '')) throw new Error('Não foi possível acessar as atualizações. Confira a internet e tente novamente.');
      throw error;
    } finally { updating = false; }
}
function securePortal(win) {
  const guard = navigationGuard(() => {
    const name = Object.keys(portals).find(k => portals[k] === win);
    if (name && state) {
      flow[name].awaiting = false;
      state[name].message = 'O portal tentou abrir um endereço que não foi reconhecido. A consulta não foi concluída.';
      emit();
    }
  });
  win.webContents.on('will-navigate', guard);
  win.webContents.on('will-redirect', guard);
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (!allowedNavigation(url)) return { action: 'deny' };
    return { action: 'allow', overrideBrowserWindowOptions: { autoHideMenuBar: true, webPreferences: { nodeIntegration: false, contextIsolation: true, sandbox: true, partition: 'persist:portais-sp', preload: path.join(__dirname, 'portal-preload.js') } } };
  });
  win.webContents.on('did-create-window', child => securePortal(child));
}
function portal(name) {
  if (!HOSTS[name]) throw new Error('Portal inválido.');
  if (portals[name] && !portals[name].isDestroyed()) return portals[name];
  const win = new BrowserWindow({ icon: path.join(__dirname, 'braga-app.ico'), width: 1120, height: 820, show: false, title: name === 'fazenda' ? 'Fazenda SP • BRAGA Consulta Veicular' : 'PGE • BRAGA Consulta Veicular', autoHideMenuBar: true,
    webPreferences: { nodeIntegration: false, contextIsolation: true, sandbox: true, partition: 'persist:portais-sp', preload: path.join(__dirname, 'portal-preload.js') } });
  portals[name] = win;
  securePortal(win);
  win.on('close', event => { if (!app.isQuitting) { event.preventDefault(); win.hide(); } });
  win.webContents.on('did-fail-load', (_event, code, _description, _url, mainFrame) => {
    if (mainFrame && code !== -3 && state && !(name === 'pge' && state.pge.source === 'Fazenda SP')) { flow[name].awaiting = false; flow[name].error = true; state[name] = pending('Não foi possível carregar o portal. Verifique a conexão e use Tentar novamente.'); emit(); }
  });
  win.webContents.on('did-finish-load', () => { if (flow[name]) flow[name].awaiting = false; void tick(); });
  win.webContents.on('render-process-gone', () => { if (state) { state[name] = pending('O navegador do portal foi interrompido. Use Tentar novamente.'); emit(); } });
  return win;
}
async function loadPortal(name, currentGeneration) {
  flow[name] = { generation: currentGeneration, prepared: false, submitted: false, loading: true, error: false };
  const win = portal(name);
  try { await win.loadURL(urls[name]); }
  catch (error) {
    if (generation === currentGeneration && state) { state[name] = pending('O portal não carregou. Abra-o para verificar ou use Tentar novamente.'); flow[name].error = true; emit(); }
  } finally { if (flow[name].generation === currentGeneration) flow[name].loading = false; }
}
function isPortalPage(win, name) {
  try { const u = new URL(win.webContents.getURL()); return u.protocol === 'https:' && u.hostname === HOSTS[name]; } catch { return false; }
}
async function execute(name, fn, argument) {
  const win = portals[name];
  if (!win || win.isDestroyed() || !isPortalPage(win, name)) return null;
  return win.webContents.executeJavaScript(scripts.script(fn, argument));
}
async function sendPge(force = false) {
  if (!state || !flow.pge.prepared) throw new Error('Aguarde o formulário da PGE ficar pronto.');
  if (state.pge.status === 'complete' || flow.pge.sending) return;
  if (force) flow.pge.awaiting = false;
  const activeFlow = flow.pge;
  const token = generation;
  activeFlow.sending = true;
  activeFlow.awaiting = true;
  activeFlow.captchaAttempted = true;
  activeFlow.startedAt = Date.now();
  activeFlow.submitted = false;
  state.pge.message = 'Enviando a consulta para a PGE…'; emit();
  try {
    const result = await execute('pge', scripts.submitPge, state.input);
    if (generation !== token || flow.pge !== activeFlow) return;
    if (result !== 'clicked') {
      activeFlow.awaiting = false;
      const message = result === 'captcha' ? 'Resolva o captcha na janela da PGE. A consulta será enviada automaticamente.' :
        result === 'mismatch' ? 'O Renavam na PGE é diferente do orçamento. Clique em Tentar novamente.' :
        'O botão Consultar não foi localizado. Abra a PGE para verificar o formulário.';
      state.pge.message = message;
    } else { activeFlow.awaiting = true; state.pge.message = 'Consulta enviada. Aguardando a resposta da PGE…'; }
  } catch {
    if (generation === token && flow.pge === activeFlow && !activeFlow.submitted) {
      activeFlow.awaiting = false;
      state.pge.message = 'Não foi possível enviar a consulta. Clique em Continuar PGE para tentar novamente.';
    }
  } finally {
    activeFlow.sending = false;
    if (generation === token && flow.pge === activeFlow) emit();
  }
}
async function updatePortal(name, token) {
  if (!state || state[name].status === 'complete' || flow[name].loading || flow[name].error) return;
  const activeFlow = flow[name];
  const stale = () => generation !== token || flow[name] !== activeFlow;
  const win = portals[name];
  if (!win || win.isDestroyed() || win.webContents.isLoadingMainFrame()) return;
  if (!isPortalPage(win, name)) {
    if (name === 'fazenda') {
const u = new URL(win.webContents.getURL());
if (u.protocol === 'https:' && u.hostname === 'sso.acesso.gov.br') {
const credentials = await readCredential();
if (credentials) await win.webContents.executeJavaScript(scripts.script(scripts.fillGovLogin, credentials));
}
state.fazenda.message = 'Conclua o login na janela da Fazenda. O programa continuará ao retornar ao portal.';
}
    return;
  }
  const input = state.input;
  if (name === 'fazenda') {
    const snapshot = await execute(name, scripts.readFazenda);
    if (!snapshot || stale()) return;
    if (snapshot.plate) {
      state.fazenda = domain.parseFazenda(snapshot, input);
      if (state.fazenda.status === 'complete' && state.pge.status !== 'complete') {
        if (domain.activeDebtClear(snapshot, input) && !state.pge.rows.length) {
          flow.pge.awaiting = false;
          state.pge = { status: 'complete', source: 'Fazenda SP', rows: [], message: 'NADA CONSTA na seção de IPVA inscrito em Dívida Ativa da Fazenda SP.', checkedAt: new Date().toISOString() };
        } else {
          state.pge.message = 'Consulta à PGE obrigatória: a Fazenda não confirmou NADA CONSTA em Dívida Ativa.';
          if (!flow.pge.generation) await loadPortal('pge', token);
        }
      }
    } else if (snapshot.formReady && !flow.fazenda.submitted) {
      flow.fazenda.submitted = true;
      state.fazenda.message = 'Consultando os débitos na Fazenda SP…';
      await execute(name, scripts.fillFazenda, input);
    } else if (snapshot.login) {
      state.fazenda.message = 'Abra a Fazenda e entre com sua conta gov.br ou certificado. A consulta continuará após o login.';
      const credentials = await readCredential();
      if (credentials) {
        const result = await execute(name, scripts.selectFazendaGovLogin);
        state.fazenda.message = result === 'clicked' || result === 'already-started' ? 'Entrando pelo gov.br com o login selecionado…' : 'Abra a Fazenda para verificar a tela de autenticação.';
      }
    } else if (snapshot.message) {
      state.fazenda.message = snapshot.message.slice(0, 500);
    } else if (!snapshot.formReady && !flow.fazenda.submitted) {
      // O login pode terminar na página inicial: retornar à consulta uma vez.
      const pathName = new URL(win.webContents.getURL()).pathname;
      if ((snapshot.loggedIn || /^\/SIVEI\/?$/i.test(pathName)) && !flow.fazenda.returned) {
        flow.fazenda.returned = true;
        await win.loadURL(FAZENDA);
      } else state.fazenda.message = 'Aguardando a página de consulta da Fazenda. Abra o portal para verificar.';
    }
  } else {
    if (!flow.pge.prepared) {
      const ready = await execute(name, scripts.preparePge, input);
      if (stale()) return;
      if (ready === 'ready') { flow.pge.prepared = true; state.pge.message = 'Abra a PGE e resolva o captcha. O programa enviará a consulta automaticamente.'; }
      return;
    }
    const snapshot = await execute(name, scripts.readPge);
    if (!snapshot || stale()) return;
    // A consulta nova pode concluir via AJAX sem gerar um POST principal que
    // o observador consiga identificar. O resultado visível, associado ao
    // mesmo Renavam, também confirma o envio.
    if (snapshot.resultPresent) {
      flow.pge.submitted = true;
      flow.pge.awaiting = false;
    }
    flow.pge.captchaReady = flow.pge.captchaReady || !!snapshot.captchaReady;
    state.pge = domain.parsePge(snapshot, input, flow.pge.submitted);
    if (state.pge.status === 'complete') return;
    if (flow.pge.awaiting) {
      state.pge.message = Date.now() - flow.pge.startedAt > 30000 ?
        'A PGE não respondeu em 30 segundos. Abra o portal para verificar ou use Tentar novamente.' :
        (flow.pge.submitted ? 'Consulta enviada. Aguardando a resposta da PGE…' : 'Aguardando o navegador enviar a consulta…');
      return;
    }
    if (flow.pge.captchaReady && !flow.pge.submitted && !flow.pge.sending && !flow.pge.awaiting) await sendPge();
    else if (snapshot.message) state.pge.message = snapshot.message.slice(0, 500);
    else if (!snapshot.captchaReady) state.pge.message = 'Resolva o captcha na janela da PGE. A consulta será enviada automaticamente.';
    else state.pge.message = 'O captcha está validado. Clique em Continuar PGE se a página não avançou.';
  }
}
async function tick() {
  if (!state || busy) return;
  busy = true;
  const token = generation;
  const before = JSON.stringify(state);
  try {
    for (const name of ['fazenda', 'pge']) {
      if (token !== generation || !state) break;
      try { await updatePortal(name, token); }
      catch { if (state && token === generation) state[name].message = 'A página está mudando ou não pôde ser lida. Aguarde ou abra o portal para verificar.'; }
    }
    if (token === generation && JSON.stringify(state) !== before) emit();
  } finally { busy = false; if (token === generation && batch?.running) finishBatchVehicle(); }
}
function registerIpc() {
  const handle = (name, fn) => ipcMain.handle(name, async (event, ...args) => { trusted(event); return fn(...args); });
  handle('detran:open', input => getDetran().open(input));
  handle('quote:image', async data => {
    if (typeof data !== 'string' || !data.startsWith('data:image/png;base64,') || data.length > 40000000) throw new Error('Imagem inválida ou muito grande.');
    const image = nativeImage.createFromDataURL(data);
    if (image.isEmpty()) throw new Error('Não foi possível gerar a imagem.');
    if (typeof clipboard.writeImage === 'function') clipboard.writeImage(image);
    else {
      const tempDir = fs.mkdtempSync(path.join(app.getPath('temp'), 'BRAGA-imagem-'));
      const imagePath = path.join(tempDir, 'orcamento.png');
      try {
        fs.writeFileSync(imagePath, image.toPNG());
        await new Promise((resolve, reject) => {
          require('node:child_process').execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-STA', '-Command', fs.readFileSync(path.join(__dirname, 'copy-image.ps1'), 'utf8').replace('param([Parameter(Mandatory=$true)][string]$ImagePath)', '$ImagePath = $env:BRAGA_IMAGE_PATH')], { windowsHide: true, timeout: 15000, env: { ...process.env, BRAGA_IMAGE_PATH: imagePath } }, error => error ? reject(new Error('O Windows não conseguiu copiar a imagem. Tente novamente.')) : resolve());
        });
      } finally { fs.rmSync(imagePath, { force: true }); fs.rmdirSync(tempDir); }
    }
    return true;
  });
  handle('history:list', () => { saveHistory(); return getHistory().list(); });
  handle('quote:edit-services', payload => {
    let target;
    if(payload.historyId!=null) target=getHistory().get(payload.historyId);
    else if(payload.batchIndex!=null) {
      const i=payload.batchIndex;
      if(!Number.isInteger(i)||!batch||i<0||i>=batch.inputs.length)throw new Error('Orçamento inválido.');
      target=batch.running&&batch.index===i?state:batch.results[i];
    } else target=state;
    if(!target||target.createdAt!==payload.createdAt||target.input.plate!==payload.plate)throw new Error('O orçamento mudou. Abra a edição novamente.');
    if(target.fazenda.status!=='complete'||target.pge.status!=='complete')throw new Error('Conclua a consulta antes de editar os serviços.');
    const extras=domain.normalizeInput({plate:target.input.plate,renavam:target.input.renavam,fee:payload.fee,services:payload.services}).extras;
    target.input={...target.input,extras};
    const same=r=>r&&r.createdAt===target.createdAt&&r.input.plate===target.input.plate&&r.input.renavam===target.input.renavam;
    if(same(state))state.input={...state.input,extras:JSON.parse(JSON.stringify(extras))};
    if(batch){batch.results.forEach((r,i)=>{if(same(r)){r.input={...r.input,extras:JSON.parse(JSON.stringify(extras))};batch.inputs[i]=r.input;}});saveBatch();}
    getHistory().save(target);
    mainWindow.webContents.send('history:changed',getHistory().list());emit();emitBatch();
    return target;
  });
  handle('history:get', id => getHistory().get(id));
  handle('history:delete', async id => {
    const record = getHistory().get(id);
    const answer = await dialog.showMessageBox(mainWindow, { type: 'question', buttons: ['Cancelar', 'Excluir'], defaultId: 0, cancelId: 0, message: 'Excluir esta consulta do histórico?', detail: record.input.plate + ' · ' + new Date(record.createdAt).toLocaleString('pt-BR') + '\nOutras consultas desta placa serão preservadas.' });
    if (answer.response !== 1) return false;
    getHistory().remove(id);
    mainWindow.webContents.send('history:changed', getHistory().list());
    return true;
  });
  handle('history:export', async ids => {
    const sheets = require('./history-report').report(getHistory(), ids);
    const result = await dialog.showSaveDialog(mainWindow, { title: 'Salvar consultas selecionadas em Excel', defaultPath: 'BRAGA-historico-' + new Date().toISOString().slice(0,10) + '.xlsx', filters: [{name:'Excel',extensions:['xlsx']}] });
    if (result.canceled) return false;
    fs.writeFileSync(result.filePath, xlsx.workbook(sheets)); return true;
  });
  async function historyPdf(ids, open) {
    const sheets = require('./history-report').report(getHistory(), ids);
    return openPdfSheet(sheets[0], open);
  }
  async function openPdfSheet(sheet, open) {
    const html = require('./history-pdf').html(sheet);
    const plates=sheet.rows.filter(row=>String(row[0]).startsWith('PLACA: ')).map(row=>String(row[0]).slice(7).replace(/[^A-Za-z0-9]/g,'').toUpperCase());
    const dateLabel=new Date().toLocaleDateString('pt-BR').replaceAll('/','-');
    const baseName=plates.length===1?plates[0]+' - Orçamento':'Orçamentos selecionados - '+dateLabel;
    const documents=app.getPath('documents');
    let file;
    if(open) {
      file=path.join(documents,baseName+'.pdf');
      let suffix=2;while(fs.existsSync(file))file=path.join(documents,baseName+' ('+(suffix++)+').pdf');
    }
    else {
      const result = await dialog.showSaveDialog(mainWindow, {title:'Salvar placas selecionadas em PDF',defaultPath:path.join(documents,baseName+'.pdf'),filters:[{name:'PDF',extensions:['pdf']}]});
      if(result.canceled) return false;
      file=result.filePath;
    }
    const win = new BrowserWindow({show:false,webPreferences:{nodeIntegration:false,contextIsolation:true,sandbox:true}});
    try {
      await win.loadURL('data:text/html;charset=utf-8,'+encodeURIComponent(html));
      const pdf = await win.webContents.printToPDF({pageSize:'A4',printBackground:true,preferCSSPageSize:true});
      fs.writeFileSync(file,pdf,open?{flag:'wx'}:undefined);
    } finally {win.destroy();}
    if(open && await shell.openPath(file)) throw new Error('Não foi possível abrir o leitor de PDF. Use Salvar PDF selecionados.');
    return true;
  }
  handle('quote:open-pdf', selection => {
    let result;
    if (selection?.historyId != null) result = getHistory().get(selection.historyId);
    else if (selection?.batchIndex != null) {
      const i = selection.batchIndex;
      if (!Number.isInteger(i) || !batch || i < 0 || i >= batch.inputs.length) throw new Error('Selecione um orçamento válido.');
      result = batch.running && batch.index === i ? state : batch.results[i];
    } else result = state;
    if (!result) throw new Error('Consulte ou abra um orçamento antes de gerar o PDF.');
    const snapshot = JSON.parse(JSON.stringify(result));
    return openPdfSheet(batchTools.report({inputs:[snapshot.input],results:[snapshot]})[0], true);
  });
  handle('history:pdf', ids=>historyPdf(ids,false));
  handle('history:open-pdf', ids=>historyPdf(ids,true));
  handle('history:open-excel', async ids => {
    const sheets = require('./history-report').report(getHistory(), ids);
    const folder = fs.mkdtempSync(path.join(app.getPath('temp'), 'BRAGA-historico-'));
    const file = path.join(folder, 'Orcamentos-selecionados.xlsx');
    fs.writeFileSync(file, xlsx.workbook(sheets));
    if (await shell.openPath(file)) throw new Error('Não foi possível abrir o Excel. Use Salvar Excel ou verifique o aplicativo instalado.');
    return true;
  });
  handle('history:copy', id => { clipboard.writeText(domain.quoteText(getHistory().get(id))); return true; });
  handle('quote:state', () => state);
  handle('batch:clear', () => {
    if (batch && (batch.running || batch.results.some(r => r && state && r.createdAt === state.createdAt && r.input.plate === state.input.plate))) { resetPortals(); state = null; }
    batch = null; fs.rmSync(batchFile, { force: true }); emit(); emitBatch(); return null;
  });
  handle('mode:single', () => {
    saveHistory();
    const ownsState = batch && state && (batch.running || batch.results.some(r => r && r.createdAt === state.createdAt && r.input.plate === state.input.plate));
    if (batch?.running) {
      batch.results[batch.index] = JSON.parse(JSON.stringify(state));
      batch.running = false;
      saveBatch();
    }
    if (ownsState) { resetPortals(); state = null; }
    emit(); emitBatch();
    return state;
  });
  handle('batch:state', () => batchView());
  handle('batch:start', input => {
    if (batch?.running) throw new Error('Já existe um lote em andamento.');
    const inputs = batchTools.parseFields(input);
    batch = { inputs, results: [], index: 0, running: true, createdAt: new Date().toISOString() };
    saveBatch(); startBatchVehicle(); return batchView();
  });
  handle('batch:fee', value => {
    if (!batch) throw new Error('Inicie um lote antes de aplicar os honorários.');
    batchTools.updateFee(batch, value);
    if (batch.running && state) state.input = batch.inputs[batch.index];
    else if (state && batch.results.some(r => r?.createdAt === state.createdAt && r.input.plate === state.input.plate)) {
      state.input = batch.inputs.find(r => r.plate === state.input.plate);
    }
    saveBatch(); emit(); emitBatch(); return batchView();
  });
  handle('batch:pause', () => {
    if (batch?.running) {
      batch.results[batch.index] = JSON.parse(JSON.stringify(state));
      batch.running = false; resetPortals(); saveBatch(); emitBatch();
    }
    return batchView();
  });
  handle('batch:resume', () => {
    if (!batch || batch.running || batch.index >= batch.inputs.length) throw new Error('Não há lote pausado para continuar.');
    batch.running = true; startBatchVehicle(); return batchView();
  });
  handle('batch:skip', () => { if (!batch?.running) throw new Error('Inicie ou continue o lote.'); finishBatchVehicle(true); return batchView(); });
  handle('batch:copy', index => {
    if (!Number.isInteger(index) || !batch || index < 0 || index >= batch.inputs.length) throw new Error('Selecione uma placa consultada.');
    const selected = batch.running && batch.index === index ? state : batch.results[index];
    if (!selected) throw new Error('Esta placa ainda não foi consultada.');
    clipboard.writeText(domain.quoteText(selected)); return true;
  });
  handle('batch:open', async () => {
    if (!batch) throw new Error('Inicie um lote antes de abrir o Excel.');
    const snapshot = JSON.parse(JSON.stringify(batch));
    if (batch.running && state) snapshot.results[batch.index] = JSON.parse(JSON.stringify(state));
    const folder = fs.mkdtempSync(path.join(app.getPath('temp'), 'BRAGA-lote-'));
    const file = path.join(folder, 'Orcamentos-lote.xlsx');
    fs.writeFileSync(file, xlsx.workbook(batchTools.report(snapshot)));
    const error = await shell.openPath(file);
    if (error) throw new Error('Não foi possível abrir o Excel. Verifique se há um aplicativo para arquivos .xlsx instalado ou use Salvar Excel.');
    return true;
  });
  handle('batch:export', async () => {
    if (!batch) throw new Error('Inicie um lote antes de exportar.');
    const snapshot = JSON.parse(JSON.stringify(batch));
    if (batch.running && state) snapshot.results[batch.index] = JSON.parse(JSON.stringify(state));
    const result = await dialog.showSaveDialog(mainWindow, { title: 'Salvar lote em Excel', defaultPath: 'BRAGA-lote-' + new Date().toISOString().slice(0,10) + '.xlsx', filters: [{ name: 'Excel', extensions: ['xlsx'] }] });
    if (result.canceled) return false;
    fs.writeFileSync(result.filePath, xlsx.workbook(batchTools.report(snapshot)));
    return true;
  });
  handle('credentials:status', async () => !!(await readCredential()));
  handle('credentials:list', () => getCredentialVault().list());
  handle('credentials:select', cpf => getCredentialVault().select(cpf));
  handle('credentials:save', input => getCredentialVault().save(input));
  handle('credentials:delete', cpf => getCredentialVault().remove(cpf));
  handle('football:get', () => require('./football').get());
  handle('football:source', () => shell.openExternal(require('./football').SOURCE));
  handle('app:update', () => checkForUpdate(false));
  handle('quote:start', async input => {
    if (batch?.running) throw new Error('Pause o lote antes de iniciar uma consulta avulsa.');
    const normalized = domain.normalizeInput(input);
    if (state) throw new Error('Clique em Nova consulta antes de consultar outro veículo.');
    generation++;
    const token = generation;
    state = { input: normalized, createdAt: new Date().toISOString(), fazenda: pending('Abrindo a Fazenda SP…'), pge: pending('Aguardando a seção de Dívida Ativa da Fazenda SP.') };
    emit();
    // As duas origens são independentes; cada uma tem sua própria janela.
    void loadPortal('fazenda', token).then(() => tick());
    return state;
  });
  handle('quote:reset', async () => {
    saveHistory();
    if (batch?.running) { batch.results[batch.index] = JSON.parse(JSON.stringify(state)); batch.running = false; saveBatch(); }
    resetPortals(); state = null;
    emit(); emitBatch(); return null;
  });
  handle('portal:show', async name => {
    if (!state) throw new Error('Inicie uma consulta.');
    const win = portal(name); win.show(); win.focus();
    if (name === 'pge') {
      const token = generation;
      if (state.pge.status === 'complete') {
        state.pge = pending('Conferência solicitada na PGE. Aguardando a nova leitura dos valores.');
        emit();
        await loadPortal('pge', token);
      } else if (!flow.pge.generation) {
        await loadPortal('pge', token);
      }
      if (generation === token) await tick();
    }
  });
  handle('portal:fine-details', async () => {
    if (!state || state.fazenda.status !== 'complete') throw new Error('Aguarde a conclusão da consulta na Fazenda para abrir as multas.');
    const win = portals.fazenda;
    if (!win || win.isDestroyed()) throw new Error('Abra a Fazenda e consulte o veículo novamente.');
    win.show(); win.focus();
    const result = await execute('fazenda', scripts.openFineDetails, state.input);
    if (result !== 'clicked') throw new Error(result === 'mismatch'
      ? 'O resultado deste veículo não está aberto na Fazenda. Retorne à consulta e tente novamente.'
      : 'O botão de detalhamento não está disponível nesta página. Confira a janela da Fazenda; os detalhes podem já estar abertos.');
    return true;
  });
  handle('portal:retry', async name => {
    if (!HOSTS[name] || !state) throw new Error('Consulta não iniciada.');
    if (name === 'fazenda' && state.pge.source === 'Fazenda SP') state.pge = pending('Aguardando nova confirmação da Fazenda SP.');
    state[name] = pending('Reabrindo o portal…'); emit();
    await loadPortal(name, generation); await tick();
  });
  handle('portal:continue', async () => {
    await sendPge(true);
    await tick();
  });
  handle('portal:ignore', () => { throw new Error('A consulta à PGE é obrigatória quando a Fazenda não informa NADA CONSTA em Dívida Ativa.'); });
  handle('quote:copy', () => { if (!state) throw new Error('Inicie uma consulta.'); clipboard.writeText(domain.quoteText(state)); return true; });
  ipcMain.on('portal:query', (event, payload) => {
    const win = portals.pge;
    if (!state || state.pge.source === 'Fazenda SP' || !win || win.isDestroyed() || !flow.pge.prepared || flow.pge.loading || event.sender !== win.webContents || event.senderFrame !== win.webContents.mainFrame || !isPortalPage(win, 'pge')) return;
    // Clique é apenas intenção; confirmação vem do POST real observado abaixo.
    const matches = domain.normalizeRenavam(payload?.renavam) === domain.normalizeRenavam(state.input.renavam);
    if (!matches) { flow.pge.submitted = false; state.pge = pending('O Renavam consultado na PGE é diferente. Use Tentar novamente.'); }
    emit();
  });
  ipcMain.on('portal:captcha-interaction', event => {
    const win = portals.pge;
    // A origem é o iframe oficial do reCAPTCHA criado pela própria PGE.
    if (!state || !win || win.isDestroyed() || !flow.pge.prepared || event.sender !== win.webContents || !isPortalPage(win, 'pge')) return;
    flow.pge.captchaReady = true;
    flow.pge.captchaAttempted = false;
    flow.pge.awaiting = false;
    state.pge.message = 'Captcha concluído. Enviando a consulta para a PGE…';
    emit();
    void tick();
  });
  ipcMain.on('portal:payment-blocked', event => {
    if (Object.values(portals).some(w => w && !w.isDestroyed() && w.webContents === event.sender) && state) {
      state.notice = 'Este aplicativo é destinado à consulta e ao orçamento. Pagamentos não são realizados.'; emit();
    }
  });
}
if (!app.requestSingleInstanceLock()) app.quit();
else {
  app.on('second-instance', () => { if (mainWindow) { if (mainWindow.isMinimized()) mainWindow.restore(); mainWindow.show(); mainWindow.focus(); } });
  app.whenReady().then(() => {
    Menu.setApplicationMenu(null);
    const portalSession = session.fromPartition('persist:portais-sp');
    portalSession.setPermissionRequestHandler((_contents, _permission, callback) => callback(false));
    portalSession.setPermissionCheckHandler(() => false);
    portalSession.webRequest.onBeforeRequest({ urls: ['https://www.dividaativa.pge.sp.gov.br/sc/pages/consultas/consultarDebito.jsf*'] }, (details, callback) => {
      try {
        const win = portals.pge;
        if (state && state.pge.source !== 'Fazenda SP' && win && !win.isDestroyed() && details.webContentsId === win.webContents.id && flow.pge.prepared && !flow.pge.loading) {
          const query = pgeSubmission(details);
          if (query) {
            const matches = domain.normalizeRenavam(query.renavam) === domain.normalizeRenavam(state.input.renavam);
            flow.pge.submitted = matches;
            flow.pge.awaiting = true;
            flow.pge.startedAt = Date.now();
            flow.pge.captchaAttempted = true;
            state.pge = pending(matches ? 'Consulta enviada. Aguardando a resposta da PGE…' : 'O Renavam enviado à PGE é diferente deste orçamento. Use Tentar novamente.');
            emit();
          }
        }
      } finally { callback({}); }
    });
    registerIpc();
    mainWindow = new BrowserWindow({ icon: path.join(__dirname, 'braga-app.ico'), width: 1240, height: 900, minWidth: 920, minHeight: 700, title: 'BRAGA Consulta Veicular 1.9.30', backgroundColor: '#f4f6fa',
      webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true } });
    mainWindow.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
    mainWindow.webContents.once('did-finish-load', () => { setTimeout(() => { if (mainWindow && !mainWindow.isDestroyed()) void checkForUpdate(true); }, 3000); });
    mainWindow.webContents.on('will-navigate', event => event.preventDefault());
    mainWindow.webContents.on('context-menu', (_event, params) => {
      const flags = params.editFlags || {};
      const items = [];
      if (params.isEditable) {
        items.push({label:'Recortar',role:'cut',enabled:!!flags.canCut});
        items.push({label:'Copiar',role:'copy',enabled:!!flags.canCopy});
        items.push({label:'Colar',role:'paste',enabled:!!flags.canPaste});
        items.push({type:'separator'});
        items.push({label:'Selecionar tudo',role:'selectAll',enabled:!!flags.canSelectAll});
      } else if (params.selectionText) {
        items.push({label:'Copiar',role:'copy',enabled:!!flags.canCopy});
      }
      if (items.length) Menu.buildFromTemplate(items).popup({window:mainWindow});
    });
    mainWindow.loadFile(path.join(__dirname, 'index.html'));
    mainWindow.on('closed', () => { mainWindow = null; app.quit(); });
    poll = setInterval(tick, 1800);
  });
  app.on('before-quit', () => { if (detranController) detranController.reset(); if (batch?.running && state) { batch.results[batch.index] = JSON.parse(JSON.stringify(state)); batch.running = false; saveBatch(); } app.isQuitting = true; clearInterval(poll); });
  app.on('window-all-closed', () => app.quit());
}

