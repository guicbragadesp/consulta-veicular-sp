'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { randomUUID } = require('node:crypto');
const accounts = require('./credentials');
function createVault(file, storage) {
  let queue = Promise.resolve();
  async function available() {
    const supported = typeof storage?.isAsyncEncryptionAvailable === 'function' ? await storage.isAsyncEncryptionAvailable() : storage?.isEncryptionAvailable?.();
    if (!supported) throw new Error('O Windows não disponibilizou o armazenamento seguro. Feche e abra o Braga e tente novamente.');
  }
  async function inspect() {
    if (!fs.existsSync(file)) return { store: accounts.normalize(null), notice: '', unreadable: false };
    await available();
    try {
      const buffer = fs.readFileSync(file);
      const decrypted = typeof storage.decryptStringAsync === 'function' ? (await storage.decryptStringAsync(buffer)).result : storage.decryptString(buffer);
      const value = JSON.parse(decrypted);
      const normalized = accounts.normalize(value);
      if (!value || (!Array.isArray(value.accounts) && !(value.cpf && value.password)) || normalized.accounts.some(a => !/^\d{11}$/.test(a.cpf) || typeof a.password !== 'string' || !a.password)) throw new Error('Invalid format');
      return { store: normalized, notice: '', unreadable: false };
    } catch {
      return { store: accounts.normalize(null), unreadable: true, notice: 'O login copiado de outro computador não pode ser aberto neste Windows. Cadastre nome, CPF e senha novamente; o arquivo anterior será preservado.' };
    }
  }
  async function write(store, previous) {
    await available();
    const data = JSON.stringify(store);
    const encrypted = typeof storage.encryptStringAsync === 'function' ? await storage.encryptStringAsync(data) : storage.encryptString(data);
    const temporary = file + '.' + randomUUID() + '.tmp';
    fs.mkdirSync(path.dirname(file), { recursive: true });
    try {
      fs.writeFileSync(temporary, encrypted);
      if (previous.unreadable && fs.existsSync(file)) fs.copyFileSync(file, file + '.outro-pc-' + randomUUID() + '.bak', fs.constants.COPYFILE_EXCL);
      fs.renameSync(temporary, file);
    } finally { if (fs.existsSync(temporary)) fs.unlinkSync(temporary); }
  }
  function mutate(fn) {
    const task = queue.then(async () => { const previous = await inspect(); const next = fn(previous); await write(next, previous); return true; });
    queue = task.catch(() => {}); return task;
  }
  return {
    async list() { const value=await inspect(); return {...accounts.publicList(value.store),notice:value.notice}; },
    async active() { const value=await inspect(); return value.store.accounts.find(a=>a.cpf===value.store.active) || null; },
    save: input => mutate(value=>accounts.save(value.store,input)),
    select: cpf => mutate(value=>{if(value.unreadable)throw new Error(value.notice);return accounts.select(value.store,cpf);}),
    remove: cpf => mutate(value=>{if(value.unreadable)throw new Error(value.notice);return accounts.remove(value.store,cpf);})
  };
}
module.exports = { createVault };
