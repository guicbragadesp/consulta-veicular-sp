'use strict';

function allowedNavigation(url) {
  try { const u = new URL(url); return u.protocol === 'https:' && (u.hostname === 'gov.br' || u.hostname.endsWith('.gov.br')); }
  catch { return false; }
}

// Electron atual fornece details.url. Versões anteriores também fornecem
// argumentos posicionais. O filtro se aplica à navegação principal, não aos
// redirecionamentos internos de frames de captcha já carregados pelo portal.
function navigationGuard(onBlocked = () => {}) {
  return function (details, legacyUrl, _legacySameDocument, legacyMainFrame) {
    const isMainFrame = typeof details.isMainFrame === 'boolean' ? details.isMainFrame : legacyMainFrame;
    if (isMainFrame === false) return;
    const url = typeof details.url === 'string' ? details.url : legacyUrl;
    if (!allowedNavigation(url)) { details.preventDefault(); onBlocked(); }
  };
}

// Lê somente a identificação do POST real. Não guarda nem devolve token de
// captcha, cookie, sessão JSF ou o restante do corpo enviado pelo navegador.
function pgeSubmission(details) {
  if (details.method !== 'POST' || details.resourceType !== 'mainFrame') return null;
  let url;
  try { url = new URL(details.url); } catch { return null; }
  if (url.protocol !== 'https:' || url.hostname !== 'www.dividaativa.pge.sp.gov.br' ||
      !/^\/sc\/pages\/consultas\/consultarDebito\.jsf(?:;[^/]*)?$/.test(url.pathname)) return null;
  const chunks = (details.uploadData || []).filter(x => x.bytes).map(x => Buffer.from(x.bytes));
  if (chunks.reduce((size, b) => size + b.length, 0) > 1024 * 1024) return null;
  const form = new URLSearchParams(Buffer.concat(chunks).toString('utf8'));
  const newRenavam = form.get('consultaDebitoForm:decTxtTipoConsulta:renavam');
  if (newRenavam !== null) return { renavam: newRenavam };
  if (form.get('adesaoForm:j_id83') !== 'RENAVAM') return { renavam: '' };
  return { renavam: form.get('adesaoForm:renavam') || '' };
}

function shouldAutoSubmit(snapshot, flow) {
  if (!snapshot.captchaReady) flow.captchaAttempted = false;
  return snapshot.formReady && snapshot.captchaReady && !snapshot.listPresent && !snapshot.noDebts &&
    !flow.awaiting && !flow.sending && !flow.captchaAttempted;
}

module.exports = { allowedNavigation, navigationGuard, pgeSubmission, shouldAutoSubmit };

