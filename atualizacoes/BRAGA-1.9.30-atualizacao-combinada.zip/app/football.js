'use strict';
const crests=require('./team-crests.json');
const SOURCE='https://jogodocorinthians.com/';
const key=s=>s.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/\s*\(rs\)/g,'').trim();
function parse(data,now=Date.now()){
 const valid=(data.fixtures||[]).filter(f=>f.status==='scheduled'&&Number.isFinite(f.kickoff)&&f.kickoff*1000>now&&[f.home,f.away].some(n=>typeof n==='string'&&key(n)==='corinthians')).sort((a,b)=>a.kickoff-b.kickoff);
 const f=valid[0];if(!f)return null;
 const clean=v=>typeof v==='string'?v.slice(0,120):'';
 return {home:clean(f.home),away:clean(f.away),homeCrest:crests[key(f.home)]||null,awayCrest:crests[key(f.away)]||null,date:new Date(f.kickoff*1000).toLocaleString('pt-BR',{timeZone:'America/Sao_Paulo',day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}),competition:clean(f.competition),broadcast:clean(f.broadcast)||'Transmissão a confirmar',source:SOURCE,checkedAt:new Date(now).toISOString()};
}
let saved,until=0;
async function get(){if(Date.now()<until)return saved;try{const r=await fetch(SOURCE+'wp-json/jdc/v1/agenda',{signal:AbortSignal.timeout(10000),redirect:'error'});if(!r.ok)throw Error();let size=0;const chunks=[];for await(const chunk of r.body){size+=chunk.length;if(size>1024*1024)throw Error();chunks.push(Buffer.from(chunk));}saved=parse(JSON.parse(Buffer.concat(chunks).toString('utf8')));until=Date.now()+5*60*1000;return saved;}catch{saved=null;until=Date.now()+60000;return null;}}
module.exports={get,parse,SOURCE};

