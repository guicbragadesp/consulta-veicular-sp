'use strict';
const $ = id => document.getElementById(id);
const api = window.veiculos;
const money = cents => (cents / 100).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
let toastTimer;
let displayedQuote = null, selectedHistory = null, historyResult = null, historyList = [], historyPage = 0;
const historySelection = new Set(), historyPageSize = 10;
let liveQuote = null, batchSnapshot = null, selectedBatch = '', queryMode = 'single';
let detranResult = null;
function render(state) { liveQuote = state; renderSelectedQuote(); }
function renderSelectedQuote() {
  const i = Number(selectedBatch);
  const viewing = selectedBatch !== '' || selectedHistory !== null;
  const selected = selectedHistory !== null ? historyResult : selectedBatch !== '' ? (batchSnapshot?.running && batchSnapshot.index === i ? batchSnapshot.current : batchSnapshot?.results[i]) : liveQuote;
  renderView(selected || null);
  $('history-banner').classList.toggle('hidden', selectedHistory === null);
  if (viewing) { $('fields').disabled = true; $('fine-details').disabled = true; $('continue').disabled = true; document.querySelectorAll('[data-show],[data-retry]').forEach(el => el.disabled = true); }
}
function toast(message) { $('toast').textContent = message; $('toast').classList.remove('hidden'); clearTimeout(toastTimer); toastTimer = setTimeout(() => $('toast').classList.add('hidden'), 4200); }
function error(message) { $('error').textContent = String(message).replace(/^Error invoking remote method '[^']+': Error: /, ''); $('error').classList.remove('hidden'); }
async function action(fn) { $('error').classList.add('hidden'); try { return await fn(); } catch (e) { error(e.message); } }
function renderView(state) {
  displayedQuote = state;
  renderDetran();
  $('edit-services').disabled = !state || state.fazenda.status!=='complete' || state.pge.status!=='complete';
  const active = !!state;
  $('fields').disabled = active;
  $('new').disabled = false;
  $('quote-pdf').disabled = !active; $('copy').disabled = !active; $('copy-image').disabled = !active;
  $('fine-details').disabled = !active || state?.fazenda.status !== 'complete';
  $('continue').disabled = !active || state?.pge.status === 'complete';
  $('ignore-pge').disabled = true;
  document.querySelectorAll('[data-show],[data-retry]').forEach(el => { el.disabled = !active; });
  $('empty').classList.toggle('hidden', active);
  $('quote').classList.toggle('hidden', !active);
  for (const name of ['fazenda', 'pge']) {
    const source = state?.[name];
    $(name + '-badge').textContent = !active ? 'Aguardando' : source.status === 'complete' ? 'Concluída ✓' : 'Pendente';
    $(name + '-badge').className = 'badge ' + (source?.status || '');
    $(name + '-message').textContent = source?.message || (name === 'fazenda' ? 'IPVA, licenciamento e multas vinculados ao veículo.' : 'Consulta independente pelo Renavam.');
  }
  const count = ['fazenda', 'pge'].filter(k => state?.[k].status === 'complete').length;
  $('progress').textContent = count + ' de 2 concluídas';
  $('pge-required').classList.toggle('hidden', !active || state.fazenda.status !== 'complete' || state.pge.status === 'complete');
  if (!active) return;
  $('result-plate').textContent = state.input.plate;
  $('result-model').textContent = state.fazenda.model || 'Aguardando identificação do veículo';
  $('result-year').textContent = 'Ano de fabricação: ' + (state.fazenda.year || '—');
  $('result-renavam').textContent = 'Renavam ' + state.input.renavam;
  const rows = window.quoteLayout.rows(state);
  $('rows').replaceChildren();
  for (const row of rows) {
    const tr = document.createElement('tr');
    const description = document.createElement('td'); description.textContent = row.description;
    const amount = document.createElement('td'); amount.textContent = money(row.cents);
    if (window.quoteLayout.extra(row)) tr.style.fontWeight = '700';
    tr.append(description, amount); $('rows').append(tr);
  }
  $('total-label').textContent = count === 2 ? 'TOTAL GERAL' : 'SUBTOTAL';
  $('total').textContent = money(rows.reduce((a, b) => a + b.cents, 0));
  $('total-note').textContent = count === 2 ? (state.pge.source === 'Fazenda SP' ? 'Fazenda conferida · Dívida Ativa: NADA CONSTA' : 'Duas consultas concluídas · soma conferida') : 'Valor parcial. Há consulta pendente.';
  $('sum').classList.toggle('complete', count === 2);
  $('pge-note').classList.toggle('hidden', !rows.some(x => x.source === 'PGE') && state.pge.source !== 'Fazenda SP');
  $('pge-note').textContent = state.pge.source === 'Fazenda SP' ? 'IPVA em dívida ativa: NADA CONSTA na Fazenda SP.' : 'Dívida ativa: valores conforme os saldos exibidos na consulta da PGE.';
  $('checked').textContent = 'Consulta iniciada em ' + new Date(state.createdAt).toLocaleString('pt-BR');
  if (state.notice) toast(state.notice);
}
$('query-form').addEventListener('submit', event => { event.preventDefault(); if (!api) return error('Abra o programa pelo arquivo Iniciar Consulta Veicular.cmd.'); action(async () => { $('start').disabled = true; try { const state = await api.start({...Object.fromEntries(new FormData(event.target)), services:readServices()}); render(state); } finally { $('start').disabled = false; } }); });
async function newConsultation() {
  detranResult = null;
  await api.reset(); selectedHistory = null; historyResult = null; selectedBatch = '';
  await setQueryMode('single'); $('query-form').reset(); $('optional-services').replaceChildren(); $('service-picker').hidden=true; $('extras').open = false;
  render(null); $('plate').focus(); document.querySelector('.form-card').scrollIntoView({behavior:'smooth',block:'start'});
}
for (const id of ['new','new-top']) $(id).addEventListener('click', () => action(newConsultation));
document.querySelectorAll('[data-show]').forEach(el => el.addEventListener('click', () => action(() => api.showPortal(el.dataset.show))));
document.querySelectorAll('[data-retry]').forEach(el => el.addEventListener('click', () => action(() => api.retry(el.dataset.retry))));
$('continue').addEventListener('click', () => action(async () => { await api.continuePge(); toast('Consulta enviada à PGE.'); }));
$('ignore-pge').addEventListener('click', () => action(async () => { await api.ignorePge(); toast('Dívida Ativa ignorada nesta consulta.'); }));
$('copy').addEventListener('click', () => action(async () => { if (selectedHistory !== null) await api.copyHistory(selectedHistory); else if (selectedBatch !== '') await api.copyBatch(Number(selectedBatch)); else await api.copy(); toast('Orçamento copiado! Abra a conversa no WhatsApp e cole com Ctrl + V.'); }));
$('fine-details').addEventListener('click', () => action(async () => { const button = $('fine-details'); button.disabled = true; try { await api.fineDetails(); } finally { render(await api.state()); } }));
$('update-app').addEventListener('click', () => action(async () => { const button = $('update-app'); button.disabled = true; button.textContent = 'Verificando / baixando…'; try { toast(await api.update()); } finally { button.disabled = false; button.textContent = 'Verificar atualizações'; } }));
$('plate').addEventListener('input', event => { event.target.value = event.target.value.toUpperCase(); });
if (api) { api.onState(render); action(async () => render(await api.state())); }
else render(null);

let savedLogins = [];
function hideLoginPassword() {
  $('login-password').type = 'password';
  $('show-password').setAttribute('aria-pressed', 'false');
  $('show-password').setAttribute('aria-label', 'Mostrar senha');
  $('show-password').title = 'Mostrar senha';
}
function showSelectedLogin() {
  const account = savedLogins.find(a => a.cpf === $('login-select').value);
  $('login-name').value = account?.name || '';
  $('login-cpf').value = account?.cpf || '';
  $('login-password').value = '';
  $('login-password').placeholder = account ? 'Senha salva. Digite para trocar.' : 'Digite a senha';
  $('delete-login').disabled = !account;
  hideLoginPassword();
}
async function refreshLogins() {
  const list = await api.listCredentials();
  savedLogins = list.accounts;
  $('login-status').textContent = list.notice || '';
  $('login-status').classList.toggle('error', !!list.notice);
  $('login-select').replaceChildren(new Option('Adicionar login', ''));
  for (const a of list.accounts) $('login-select').add(new Option(a.name + ' · CPF final ' + a.cpf.slice(-4), a.cpf));
  $('login-select').value = list.active || '';
  const active = list.accounts.find(a => a.cpf === list.active);
  $('login-summary').textContent = active ? active.name + ' · Alterar ▾' : 'Configurar ▾';
  showSelectedLogin();
}
$('login-select').addEventListener('change', () => action(async () => {
  if ($('login-select').value) { await api.selectCredentials($('login-select').value); await refreshLogins(); toast('Login selecionado para a Fazenda e o Detran.'); }
  else showSelectedLogin();
}));
$('show-password').addEventListener('click', () => {
  const show = $('login-password').type === 'password';
  $('login-password').type = show ? 'text' : 'password';
  $('show-password').setAttribute('aria-pressed', String(show));
  $('show-password').setAttribute('aria-label', show ? 'Ocultar senha' : 'Mostrar senha');
  $('show-password').title = show ? 'Ocultar senha' : 'Mostrar senha';
});
$('credentials').addEventListener('toggle', () => { if (!$('credentials').open) hideLoginPassword(); });
$('save-login').addEventListener('click', async () => {
  const button = $('save-login'); button.disabled = true; button.textContent = 'Salvando…';
  $('login-status').textContent = ''; $('login-status').classList.remove('error');
  try {
    await api.saveCredentials({ name: $('login-name').value, cpf: $('login-cpf').value, password: $('login-password').value });
    await refreshLogins(); $('credentials').open = false; toast('Login salvo e selecionado para Fazenda e Detran.');
  } catch (error) {
    $('login-status').textContent = String(error.message).replace(/^Error invoking remote method '[^']+': Error: /, '');
    $('login-status').classList.add('error'); $('credentials').open = true;
  } finally { button.disabled = false; button.textContent = 'Salvar login'; }
});
$('delete-login').addEventListener('click', () => action(async () => {
  await api.deleteCredentials($('login-select').value); await refreshLogins(); toast('Login removido.');
}));
if (api) refreshLogins().catch(error => { $('login-status').textContent = error.message; $('login-status').classList.add('error'); });

let batchRunning = false;
function renderBatch(value) {
  const justFinished = batchSnapshot?.running && value && !value.running && value.index >= value.inputs.length && batchSnapshot.createdAt === value.createdAt;
  if (justFinished) {
    $('batch-plates').value = '';
    $('batch-renavams').value = '';
    $('batch-pair').textContent = 'Lote finalizado. Placas e Renavams limpos; resultados preservados.';
  }
  batchSnapshot = value;
  $('quote-picker-label').classList.toggle('hidden', !value || queryMode !== 'batch');
  const picker = $('quote-picker');
  picker.replaceChildren(new Option('Acompanhar consulta atual', ''));
  if (value) value.inputs.forEach((input,i) => { const available = !!value.results[i] || (value.running && value.index === i); const option = new Option(input.plate + (available ? '' : ' — na fila'), String(i)); option.disabled = !available; picker.add(option); });
  if (!value || Number(selectedBatch) >= value.inputs.length) selectedBatch = '';
  picker.value = selectedBatch;
  batchRunning = !!value?.running;
  validateBatchFee();
  $('batch-fee').disabled = false;
  for (const field of ['plates','renavams','transfer','inspection','plateService','otherValue','otherLabel']) $('batch-' + field).disabled = false;
  $('batch-pause').disabled = !batchRunning; $('batch-skip').disabled = !batchRunning;
  $('batch-resume').disabled = !value || batchRunning || value.index >= value.inputs.length;
  $('batch-export').disabled = !value; $('batch-open').disabled = !value;
  renderSelectedQuote();
  $('batch-rows').replaceChildren();
  if (!value) return;
  $('batch-status').textContent = value.index >= value.inputs.length ? 'Lote finalizado. Clique em Salvar Excel para gerar o arquivo.' : (batchRunning ? 'Consultando ' : 'Lote pausado em ') + (value.index + 1) + ' de ' + value.inputs.length + '. Use Abrir Fazenda ou Abrir PGE abaixo quando precisar concluir login ou captcha.';
  value.inputs.forEach((input,i) => {
    const result = i === value.index && value.current ? value.current : value.results[i];
    const complete = result?.fazenda?.status === 'complete' && result?.pge?.status === 'complete';
    const status = complete ? 'Concluído' : i === value.index && batchRunning ? 'Em consulta' : result ? 'Pendente' : 'Na fila';
    const cents = result ? [...result.fazenda.rows,...result.pge.rows,...result.input.extras].reduce((a,r)=>a+r.cents,0) : null;
    const tr = document.createElement('tr');
    for (const text of [input.plate,status,cents === null ? '—' : (complete ? '' : 'Subtotal: ') + money(cents)]) { const td=document.createElement('td'); td.textContent=text; tr.append(td); }
    $('batch-rows').append(tr);
  });
}
$('batch-start').addEventListener('click',()=>action(async()=>{
  if ($('batch-rows').children.length && !window.confirm('Iniciar outro lote substitui o lote anterior salvo. Já exportou o Excel que deseja guardar?')) return;
  if (!validateBatchFee()) { $('batch-error').textContent = 'Informe os honorários antes de iniciar. Use 0 se não houver cobrança.'; $('batch-error').classList.remove('hidden'); $('batch-fee').focus(); return; }
  $('batch-error').classList.add('hidden');
  selectedBatch = ''; renderBatch(await api.startBatch(Object.fromEntries(['plates','renavams','fee','transfer','inspection','plateService','otherValue','otherLabel'].map(field => [field, $('batch-' + field).value]))));
}));
$('batch-pause').addEventListener('click',()=>action(async()=>renderBatch(await api.pauseBatch())));
$('batch-resume').addEventListener('click',()=>action(async()=>renderBatch(await api.resumeBatch())));
$('batch-skip').addEventListener('click',()=>action(async()=>renderBatch(await api.skipBatch())));
$('batch-export').addEventListener('click',()=>action(async()=>{if(await api.exportBatch())toast('Planilha Excel salva.');}));
if(api){ api.onBatch(renderBatch); action(async()=>renderBatch(await api.batchState())); }

$('quote-picker').addEventListener('change', () => { selectedHistory = null; historyResult = null; selectedBatch = $('quote-picker').value; renderSelectedQuote(); });
$('batch-open').addEventListener('click', () => action(async () => { if (await api.openBatch()) toast('Excel aberto para visualizar. Use Salvar Excel para guardar uma cópia.'); }));


function batchLine(field) { return field.value.slice(0, field.selectionStart).split('\n').length - 1; }
function showBatchPair(field) {
  const line = batchLine(field);
  const plate = $('batch-plates').value.split('\n')[line]?.trim() || 'sem placa';
  const renavam = $('batch-renavams').value.split('\n')[line]?.trim() || 'sem Renavam';
  $('batch-pair').textContent = 'Linha ' + (line + 1) + ': ' + plate + ' ↔ ' + renavam + ' · Tab: Renavam; Shift + Tab: placa.';
}
for (const id of ['batch-plates','batch-renavams']) {
  const field = $(id);
  for (const event of ['click','keyup','input','focus']) field.addEventListener(event, () => showBatchPair(field));
  field.addEventListener('keydown', event => {
    const forward = id === 'batch-plates' && !event.shiftKey;
    const backward = id === 'batch-renavams' && event.shiftKey;
    if (event.key !== 'Tab' || (!forward && !backward)) return;
    event.preventDefault();
    const target = $(forward ? 'batch-renavams' : 'batch-plates');
    const line = batchLine(field), lines = target.value.split('\n');
    while (lines.length <= line) lines.push('');
    target.value = lines.join('\n');
    const offset = lines.slice(0,line).reduce((n,text) => n + text.length + 1,0);
    target.focus(); target.setSelectionRange(offset,offset + lines[line].length); showBatchPair(target);
  });
}

async function setQueryMode(mode) {
  selectedHistory = null; historyResult = null;
  if (mode === 'single') {
    selectedBatch = '';
    const current = await api.switchToSingle();
    renderBatch(await api.batchState());
    render(current);
    if (!current) { $('query-form').reset(); $('optional-services').replaceChildren(); $('service-picker').hidden=true; $('extras').open = false; }
  }
  queryMode = mode;
  const isBatch = mode === 'batch';
  $('batch-panel').classList.toggle('hidden', !isBatch);
  if (isBatch) $('batch-panel').open = true;
  document.querySelector('.form-card').classList.toggle('hidden', isBatch);
  document.querySelector('.layout').classList.toggle('batch-layout', isBatch);
  for (const key of ['single','batch']) { $('mode-' + key).className = key === mode ? 'primary' : 'secondary'; $('mode-' + key).setAttribute('aria-pressed', String(key === mode)); }
  $('quote-picker-label').classList.toggle('hidden', !isBatch || !batchSnapshot);
  if (!isBatch) $('plate').focus();
}
$('mode-single').addEventListener('click', () => action(() => setQueryMode('single')));
$('mode-batch').addEventListener('click', () => action(() => setQueryMode('batch')));
$('batch-clear').addEventListener('click', () => action(async () => {
  if (batchSnapshot && !window.confirm('Limpar a lista e os resultados deste lote? Exporte o Excel antes se quiser guardar. Arquivos já salvos serão mantidos.')) return;
  await api.clearBatch();
  selectedBatch = '';
  for (const key of ['plates','renavams','fee','transfer','inspection','plateService','otherValue','otherLabel']) $('batch-' + key).value = '';
  $('batch-error').classList.add('hidden');
  $('batch-status').textContent = '';
  $('batch-pair').textContent = 'Use Tab para ir da placa ao Renavam da mesma linha.';
  renderBatch(null); render(await api.state());
  toast('Lote limpo. Você pode iniciar outro.');
}));

function validateBatchFee() {
  const text = $('batch-fee').value.trim();
  const valid = /^(?:\d+|\d{1,3}(?:\.\d{3})+)(?:,\d{1,2})?$/.test(text);
  $('batch-start').disabled = batchRunning || !valid;
  $('batch-fee').setAttribute('aria-invalid', String(!valid));
  $('batch-fee-notice').textContent = valid ? 'Este valor é aplicado automaticamente a todas as placas do lote.' : 'Obrigatório: informe 0 (sem cobrança) ou o valor dos honorários para iniciar.';
  return valid;
}
$('batch-fee').addEventListener('input', () => {
  if (!validateBatchFee() || !batchSnapshot || !api) return;
  const fee = $('batch-fee').value;
  action(async () => { await api.updateBatchFee(fee); });
});
validateBatchFee();

$('copy-image').addEventListener('click', () => action(async () => {
  if (!displayedQuote) throw new Error('Selecione um orçamento.');
  const snapshot = JSON.parse(JSON.stringify(displayedQuote));
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  const width = 1000, padding = 44, lineHeight = 32;
  const entries = [];
  function textLines(text, maxWidth, bold = false, size = 23) {
    ctx.font = (bold ? 'bold ' : '') + size + 'px Arial';
    const lines = []; let current = '';
    for (const word of String(text).split(/\s+/)) {
      if (current && ctx.measureText(current + ' ' + word).width > maxWidth) { lines.push(current); current = ''; }
      current += (current ? ' ' : '') + word;
    }
    if (current) lines.push(current);
    return lines.length ? lines : [''];
  }
  function add(text, amount = null, bold = false, total = false) {
    const lines = textLines(text, total ? 540 : amount === null ? width - padding * 2 : 655, bold, total ? 30 : 23);
    entries.push({ lines, amount, bold, total, height: lines.length * lineHeight + (total ? 38 : 22) });
  }
  const modelLines = textLines(snapshot.fazenda.model || 'Aguardando identificação do veículo', 590, true);
  const headerHeight = 110 + Math.max(120, modelLines.length * lineHeight + 70);
  add('DESCRIÇÃO', 'VALOR');
  const rows = window.quoteLayout.rows(snapshot);
  rows.forEach(row => add(row.description, money(row.cents), window.quoteLayout.extra(row)));
  const complete = snapshot.fazenda.status === 'complete' && snapshot.pge.status === 'complete';
  add(complete ? 'TOTAL GERAL' : 'SUBTOTAL — CONSULTA PENDENTE', money(rows.reduce((sum,row)=>sum+row.cents,0)), true, true);
  if (!complete) for (const key of ['fazenda','pge']) if (snapshot[key].status !== 'complete') add((key === 'fazenda' ? 'Fazenda: ' : 'PGE: ') + snapshot[key].message);
  add('Consulta em ' + new Date(snapshot.createdAt).toLocaleString('pt-BR'));
  const height = padding * 2 + headerHeight + entries.reduce((sum,row)=>sum+row.height,0);
  if (height > 30000) throw new Error('Orçamento muito extenso para uma imagem. Use a exportação Excel.');
  canvas.width = width; canvas.height = height;
  ctx.fillStyle = '#ffffff'; ctx.fillRect(0,0,width,height);
  ctx.textBaseline='top';ctx.fillStyle='#142c40';ctx.font='bold 30px Arial';ctx.fillText('Orçamento veicular',padding,padding);
  const plateY=padding+70, plateWidth=260;
  ctx.fillStyle='#fff';ctx.fillRect(padding,plateY,plateWidth,110);ctx.strokeStyle='#222';ctx.lineWidth=2;ctx.strokeRect(padding,plateY,plateWidth,110);
  ctx.fillStyle='#164596';ctx.fillRect(padding+1,plateY+1,plateWidth-2,30);
  ctx.textAlign='center';ctx.fillStyle='#fff';ctx.font='bold 17px Arial';ctx.fillText('BRASIL',padding+plateWidth/2,plateY+7);
  ctx.fillStyle='#111';ctx.font='bold 43px monospace';ctx.fillText(snapshot.input.plate,padding+plateWidth/2,plateY+46);ctx.textAlign='left';
  const infoX=padding+290;ctx.fillStyle='#142c40';ctx.font='bold 23px Arial';modelLines.forEach((line,i)=>ctx.fillText(line,infoX,plateY+i*lineHeight));
  ctx.font='20px Arial';ctx.fillStyle='#657484';ctx.fillText('Ano: '+(snapshot.fazenda.year||'—'),infoX,plateY+modelLines.length*lineHeight+6);
  ctx.fillText('Renavam: '+snapshot.input.renavam,infoX,plateY+modelLines.length*lineHeight+36);
  ctx.lineWidth=1;
  let y = padding + headerHeight;
  for (const entry of entries) {
    if (entry === entries[0]) { ctx.fillStyle='#f4f6fa'; ctx.fillRect(padding-12,y-7,width-padding*2+24,entry.height); }
    if (entry.bold && !entry.total) { ctx.fillStyle = '#f7fbff'; ctx.fillRect(padding - 12,y - 7,width - padding * 2 + 24,entry.height); }
    if (entry.total) { ctx.fillStyle='#fff'; ctx.fillRect(padding-12,y-7,width-padding*2+24,entry.height); ctx.strokeStyle='#aaa'; ctx.lineWidth=2; ctx.strokeRect(padding-12,y-7,width-padding*2+24,entry.height); ctx.lineWidth=1; }
    ctx.fillStyle = '#142c40'; ctx.font = (entry.bold ? 'bold ' : '') + (entry.total ? '30px Arial' : '23px Arial'); ctx.textBaseline = 'top';
    entry.lines.forEach((line,i)=>ctx.fillText(line,padding,y+i*lineHeight));
    if (entry.amount !== null) {
      ctx.textAlign = 'right'; ctx.fillText(entry.amount,width-padding,y);
      if (entry.total) { const amountWidth=ctx.measureText(entry.amount).width; ctx.fillStyle='#0f766e'; ctx.fillText('➜',width-padding-amountWidth-12,y); }
      ctx.textAlign='left';
    }
    y += entry.height;
    ctx.strokeStyle='#e2e8ef'; ctx.beginPath(); ctx.moveTo(padding,y-9); ctx.lineTo(width-padding,y-9); ctx.stroke();
  }
  await api.copyImage(canvas.toDataURL('image/png'));
  toast('Imagem copiada! Abra o WhatsApp e cole com Ctrl + V.');
}));

function updateHistorySelection() {
  const chosen = historyList.filter(item => historySelection.has(item.id));
  const partial = chosen.some(item => !item.complete);
  $('history-selection').textContent = chosen.length + ' placa(s) selecionada(s)' + (chosen.length ? ' · ' + (partial ? 'Subtotal parcial: ' : 'Total: ') + money(chosen.reduce((sum,item)=>sum+item.total,0)) : ' · Marque as consultas para gerar Excel ou PDF.');
  for (const id of ['history-export','history-open-excel','history-pdf','history-open-pdf','history-clear-selection']) $(id).disabled = !chosen.length;
  document.querySelectorAll('#history-rows input[type="checkbox"]').forEach(box=>{box.checked=historySelection.has(box.dataset.historyId);});
}
function renderHistoryList() {
  const existing = new Set(historyList.map(item => item.id));
  for (const id of historySelection) if (!existing.has(id)) historySelection.delete(id);
  if (selectedHistory !== null && !existing.has(selectedHistory)) { selectedHistory = null; historyResult = null; renderSelectedQuote(); }
  updateHistorySelection();
  const filter = $('history-search').value.replace(/[\s-]/g,'').toUpperCase();
  $('history-rows').replaceChildren();
  const matches = historyList.filter(item => (item.plate + item.renavam).toUpperCase().includes(filter));
  historyPage = Math.min(historyPage, Math.max(0, Math.ceil(matches.length / historyPageSize) - 1));
  const entries = matches.slice(historyPage * historyPageSize, (historyPage + 1) * historyPageSize);
  $('history-prev').disabled = historyPage === 0;
  $('history-next').disabled = (historyPage + 1) * historyPageSize >= matches.length;
  $('history-empty').textContent = matches.length ? 'Mostrando ' + (historyPage * historyPageSize + 1) + '–' + (historyPage * historyPageSize + entries.length) + ' de ' + matches.length + '. Busque uma placa para localizar consultas anteriores.' : 'Nenhuma consulta salva encontrada.';
  for (const item of entries) {
    const row = document.createElement('tr'), name = document.createElement('td'), status = document.createElement('td'), controls = document.createElement('td'), open = document.createElement('button');
    const selectCell = document.createElement('td'), checkbox = document.createElement('input');
    checkbox.dataset.historyId = item.id; checkbox.type = 'checkbox'; checkbox.checked = historySelection.has(item.id);
    checkbox.setAttribute('aria-label','Selecionar ' + item.plate + ' de ' + new Date(item.createdAt).toLocaleString('pt-BR'));
    checkbox.addEventListener('change',()=>{
      if (checkbox.checked) { const replaced = historyList.some(entry=>entry.plate===item.plate && entry.id!==item.id && historySelection.has(entry.id)); for (const entry of historyList) if (entry.plate === item.plate) historySelection.delete(entry.id); historySelection.add(item.id); if(replaced)toast('Data da placa '+item.plate+' substituída na seleção. A mesma placa entra uma vez na soma.'); }
      else historySelection.delete(item.id);
      updateHistorySelection();
    });
    selectCell.append(checkbox);
    name.textContent = item.plate + ' · ' + new Date(item.createdAt).toLocaleString('pt-BR');
    status.textContent = (item.complete ? 'Total: ' : 'Pendente · subtotal: ') + money(item.total);
    open.textContent = 'Abrir'; open.className = 'secondary small';
    open.addEventListener('click',()=>action(async()=>{
      const result = await api.getHistory(item.id);
      selectedHistory = item.id; historyResult = result; selectedBatch = '';
      renderSelectedQuote(); document.querySelector('.budget').scrollIntoView({behavior:'smooth',block:'start'});
    }));
    const remove = document.createElement('button'); remove.textContent = 'Excluir'; remove.className = 'secondary small';
    remove.addEventListener('click',()=>action(async()=>{if(await api.deleteHistory(item.id)){historySelection.delete(item.id);await refreshHistory();toast('Consulta excluída do histórico.');}}));
    const renew = document.createElement('button'); renew.textContent = 'Atualizar pesquisa'; renew.className = 'secondary small';
    renew.addEventListener('click',()=>action(()=>renewHistory(item.id)));
    controls.append(open,renew,remove); row.append(selectCell,name,status,controls); $('history-rows').append(row);
  }
}
async function renewHistory(id) {
  const previous = await api.getHistory(id);
  await newConsultation();
  $('plate').value = previous.input.plate;
  $('renavam').value = previous.input.renavam;
  $('fee').focus();
  toast('Placa e Renavam preenchidos. Informe os honorários (0 ou o valor) e clique em Consultar veículo para atualizar.');
}
async function refreshHistory() { historyList = await api.listHistory(); renderHistoryList(); }
$('history-panel').addEventListener('toggle',()=>{if($('history-panel').open) action(refreshHistory);});
$('history-refresh').addEventListener('click',()=>action(refreshHistory));
$('history-clear-selection').addEventListener('click',()=>{historySelection.clear();renderHistoryList();});
$('history-export').addEventListener('click',()=>action(async()=>{if(await api.exportHistory([...historySelection]))toast('Excel das consultas selecionadas salvo.');}));
$('history-open-excel').addEventListener('click',()=>action(()=>api.openHistoryExcel([...historySelection])));
$('history-search').addEventListener('input',()=>{historyPage=0;renderHistoryList();});
$('history-prev').addEventListener('click',()=>{historyPage=Math.max(0,historyPage-1);renderHistoryList();});
$('history-next').addEventListener('click',()=>{historyPage++;renderHistoryList();});
$('history-back').addEventListener('click',()=>{selectedHistory=null;historyResult=null;renderSelectedQuote();});
if(api) api.onHistoryError(message=>error(message));

if (api) { api.onHistoryChanged(entries => { historyList = entries; renderHistoryList(); }); action(refreshHistory); }

$('history-select-all').addEventListener('click',()=>{
 const filter=$('history-search').value.replace(/[\s-]/g,'').toUpperCase();
 const seen=new Set();
 for(const item of historyList) {
  if(!(item.plate+item.renavam).toUpperCase().includes(filter)||seen.has(item.plate))continue;
  seen.add(item.plate);
  for(const entry of historyList)if(entry.plate===item.plate)historySelection.delete(entry.id);
  historySelection.add(item.id);
 }
 updateHistorySelection();
});
$('history-pdf').addEventListener('click',()=>action(async()=>{if(await api.exportHistoryPdf([...historySelection]))toast('PDF das placas selecionadas salvo.');}));

$('history-open-pdf').addEventListener('click',()=>action(()=>api.openHistoryPdf([...historySelection])));

$('quote-pdf').addEventListener('click',()=>action(async()=>{const button=$('quote-pdf');button.disabled=true;try{await api.openQuotePdf(selectedHistory!==null?{historyId:selectedHistory}:selectedBatch!==''?{batchIndex:Number(selectedBatch)}:{});}finally{button.disabled=!displayedQuote;}}));

function readServices() {
 return [...document.querySelectorAll('#optional-services .optional-service')].map(row=>({type:row.querySelector('select').value,description:row.querySelector('[data-description]').value,value:row.querySelector('[data-value]').value}));
}

$('add-service').addEventListener('click',()=>{
 const picker=$('service-picker');picker.hidden=!picker.hidden;picker.value='';if(!picker.hidden)picker.focus();
});
$('service-picker').addEventListener('change',()=>{
 const picker=$('service-picker'),type=picker.value;if(!type)return;
 if(['transfer','inspection','plateService'].includes(type)){ $(type).focus(); picker.hidden=true; picker.value=''; return; }
 const existing=[...$('optional-services').children].find(row=>row.dataset.type===type);
 if(type!=='other'&&existing){existing.querySelector('[data-value]').focus();picker.hidden=true;toast('Este serviço já foi adicionado. Edite o valor na mesma linha.');return;}
 if($('optional-services').children.length>=30){toast('Limite de 30 serviços por orçamento.');return;}
 const row=document.createElement('div');row.className='optional-service';row.dataset.type=type;
 const select=document.createElement('select');select.hidden=true;select.add(new Option(picker.options[picker.selectedIndex].text,type));
 const title=document.createElement('strong');title.textContent=picker.options[picker.selectedIndex].text;
 const description=document.createElement('input');description.dataset.description='';description.maxLength=100;description.placeholder='Nome do serviço';description.setAttribute('aria-label','Descrição do serviço');description.hidden=type!=='other';description.required=type==='other';
 const value=document.createElement('input');value.dataset.value='';value.inputMode='decimal';value.placeholder='Valor R$';value.required=true;value.setAttribute('aria-label','Valor de '+title.textContent);
 const remove=document.createElement('button');remove.type='button';remove.className='secondary small';remove.textContent='Remover';remove.addEventListener('click',()=>row.remove());
 row.append(select,title,description,value,remove);$('optional-services').append(row);picker.hidden=true;picker.value='';if(type==='other')description.focus();else value.focus();
});

let editingTarget=null;
function addEditableService(description='',amount=''){
 const row=document.createElement('div');row.className='edit-service-row';
 const label=document.createElement('input');label.placeholder='Nome do serviço';label.setAttribute('aria-label','Serviço');label.maxLength=100;label.required=true;label.value=description;
 const value=document.createElement('input');value.placeholder='Valor R$';value.setAttribute('aria-label','Valor do serviço');value.inputMode='decimal';value.required=true;value.value=amount;
 const remove=document.createElement('button');remove.type='button';remove.textContent='Remover';remove.className='secondary';remove.onclick=()=>row.remove();row.append(label,value,remove);$('edit-service-rows').append(row);
}
$('edit-services').onclick=()=>{
 if(!displayedQuote)return;
 editingTarget={...(selectedHistory!==null?{historyId:selectedHistory}:selectedBatch!==''?{batchIndex:Number(selectedBatch)}:{}),createdAt:displayedQuote.createdAt,plate:displayedQuote.input.plate};
 $('edit-error').textContent='';$('edit-service-rows').replaceChildren();
 $('edit-fee').value=((displayedQuote.input.extras.find(r=>r.id==='honorarios')?.cents||0)/100).toFixed(2).replace('.',',');
 displayedQuote.input.extras.filter(r=>r.id!=='honorarios').forEach(r=>addEditableService(r.description,(r.cents/100).toFixed(2).replace('.',',')));
 $('service-editor').showModal();
};
$('edit-add').onclick=()=>addEditableService();$('edit-cancel').onclick=()=>$('service-editor').close();
$('service-edit-form').onsubmit=async event=>{
 event.preventDefault();const button=event.submitter;button.disabled=true;
 try{
 const services=[...$('edit-service-rows').children].map(row=>({type:'other',description:row.children[0].value,value:row.children[1].value}));
 const updated=await api.editServices({...editingTarget,fee:$('edit-fee').value,services});
 if(selectedHistory!==null)historyResult=updated;
 else if(selectedBatch!==''&&batchSnapshot)batchSnapshot.results[Number(selectedBatch)]=updated;
 else liveQuote=updated;
 renderSelectedQuote();$('service-editor').close();toast('Honorários e serviços atualizados.');
 }catch(e){$('edit-error').textContent=e.message;}finally{button.disabled=false;}
};

// Delegation also handles optional services created after the page loads.
function formatCurrencyField(field){
 if(field && field.matches('input[inputmode="decimal"]'))field.value=window.formatMoneyInput(field.value);
}
document.addEventListener('focusout',event=>formatCurrencyField(event.target));
document.addEventListener('submit',()=>document.querySelectorAll('input[inputmode="decimal"]').forEach(formatCurrencyField),true);

async function refreshFootball(){try{const f=await api.football();const teams=$('football-teams');teams.replaceChildren();if(!f){teams.textContent='Agenda indisponível · abrir fonte';$('football-time').textContent='';$('football-tv').textContent='';return;}for(const [i,name,crest] of [[0,f.home,f.homeCrest],[1,f.away,f.awayCrest]]){if(i)teams.append(document.createTextNode(' × '));if(crest){const img=document.createElement('img');img.src=crest;img.alt='';teams.append(img);}teams.append(document.createTextNode(name));}$('football-time').textContent=f.date+' (Brasília) · '+f.competition;$('football-tv').textContent='📺 '+f.broadcast;$('football').title='Fonte: Jogo do Corinthians · Conferido em '+new Date(f.checkedAt).toLocaleString('pt-BR')+' · Clique para abrir';}catch{$('football-teams').textContent='Agenda indisponível · abrir fonte';}}
$('football').addEventListener('click',()=>api.footballSource());refreshFootball();setInterval(refreshFootball,300000);

function detranInput() {
  return displayedQuote?.input || { plate: $('plate').value, renavam: $('renavam').value };
}
function sameDetranVehicle(a,b) {
  const p=v=>String(v||'').toUpperCase().replace(/[^A-Z0-9]/g,'');
  const r=v=>String(v||'').replace(/\D/g,'').replace(/^0+/,'');
  return a && b && p(a.plate)===p(b.plate) && r(a.renavam)===r(b.renavam);
}
function renderDetran() {
  const input=detranInput();
  const result=sameDetranVehicle(input,detranResult?.input) ? detranResult : null;
  $('detran-vehicle').textContent=result ? 'Placa '+result.input.plate+' · Renavam '+result.input.renavam : '';
  $('detran-badge').textContent=result?.alerts.length ? 'Atenção' : result?.status==='complete' ? 'Conferido ✓' : result ? 'Pendente' : 'Não consultado';
  $('detran-badge').className='badge '+(result?.alerts.length ? 'detran-warning' : result?.status==='complete' ? 'complete' : '');
  $('detran-message').textContent=result?.message || 'Informe placa e Renavam nos dados da consulta ou abra um orçamento.';
  $('detran-alert').classList.toggle('hidden',!result?.alerts.length);
  $('detran-alert').textContent=result?.alerts.map(row=>row.title+': '+row.value).join(' · ') || '';
  $('detran-rows').replaceChildren();
  for(const row of result?.rows || []) {
    const title=document.createElement('dt'),value=document.createElement('dd');
    title.textContent=row.title; value.textContent=row.value; if(row.alert)value.className='detran-warning-text';
    $('detran-rows').append(title,value);
  }
}
$('open-detran').addEventListener('click',()=>action(async()=>{
  const button=$('open-detran'); button.disabled=true;
  try { await api.openDetran(detranInput()); } finally {button.disabled=false;}
}));
for(const id of ['plate','renavam'])$(id).addEventListener('input',renderDetran);
if(api)api.onDetran(result=>{detranResult=result;renderDetran();});
