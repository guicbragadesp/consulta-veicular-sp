'use strict';
// Steps observed on the official Detran-SP page. Never clicks payments, certificates or captcha.
function advance(input) {
  if (location.protocol !== 'https:' || !['www.detran.sp.gov.br','detran.sp.gov.br'].includes(location.hostname)) return 'blocked';
  const visible=el=>!!el && !el.disabled && el.getClientRects().length>0 && getComputedStyle(el).visibility!=='hidden';
  const normalize=v=>String(v||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/\s+/g,' ').trim().toLowerCase();
  const controls=Array.from(document.querySelectorAll('button,a,input[type=submit]')).filter(visible);
  const text=el=>normalize(el.innerText||el.value||el.textContent);
  const renew=controls.filter(el=>text(el)==='fazer login');
  if(renew.length===1) {
    if(renew[0].dataset.bragaDetranLogin)return 'awaiting-login';
    renew[0].dataset.bragaDetranLogin='true';renew[0].click();return 'login-selected';
  }
  const modal=document.querySelector('[role="dialog"]');
  if(visible(modal))return 'manual-confirmation';
  const fields=[document.getElementById('placa-input'),document.getElementById('renavam-input')];
  if(fields.every(visible)) {
    const expected=[input.plate,String(input.renavam).padStart(11,'0')];
    for(let i=0;i<fields.length;i++) {
      const field=fields[i];
      if(field.value && field.value.toUpperCase()!==expected[i])return 'different-input';
      if(field.value!==expected[i]) {
        const setter=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set;
        setter.call(field,expected[i]);field.dispatchEvent(new Event('input',{bubbles:true}));field.dispatchEvent(new Event('change',{bubbles:true}));field.dispatchEvent(new Event('blur',{bubbles:true}));
      }
    }
    if(fields[0].dataset.bragaDetranSubmitted)return 'awaiting-result';
    const submit=controls.filter(el=>text(el)==='consultar' && el.getAttribute('ng-click')==='c.consulta()');
    if(submit.length!==1)return 'awaiting-validation';
    if(fields.some((field,i)=>field.value.toUpperCase()!==expected[i]))return 'awaiting-validation';
    fields[0].dataset.bragaDetranSubmitted='true';submit[0].click();return 'submitted';
  }
  if(document.querySelector('.restricoes-section')?.getClientRects().length)return 'result';
  const third=controls.filter(el=>el.getAttribute('ng-click')==="c.tipoServico('terceiros')");
  if(third.length===1) {
    if(third[0].dataset.bragaDetranStarted)return 'awaiting-form';
    third[0].dataset.bragaDetranStarted='true';third[0].click();return 'third-party-selected';
  }
  const login=controls.filter(el=>/^(?:realizar login|entrar(?: com)? (?:o )?gov\.?br|entrar com sua conta gov\.?br|login gov\.?br)$/.test(text(el)));
  if(login.length===1) {
    if(login[0].tagName==='A') {const url=new URL(login[0].href,location.href);if(url.protocol!=='https:'||!(url.hostname==='gov.br'||url.hostname.endsWith('.gov.br')))return 'blocked';}
    if(login[0].dataset.bragaDetranLogin)return 'awaiting-login';
    login[0].dataset.bragaDetranLogin='true';login[0].click();return 'login-selected';
  }
  if(location.pathname && !location.pathname.includes('/servicos/veiculos/consultar_debitos_restricoes') && visible(document.querySelector('#dropdownProfile .avatar-circle')))return 'return-to-service';
  return 'manual-login';
}
function message(step) {
  if(step==='manual-confirmation')return 'Conclua a confirmação ou o captcha mostrado pelo Detran. A pesquisa continuará quando a janela for liberada.';
  if(step==='return-to-service')return 'Retornando à pesquisa de débitos e restrições do Detran-SP…';
  return ({'different-input':'O formulário contém dados de outro veículo. Confira placa e Renavam na janela do Detran antes de continuar.', 'submitted':'Consulta enviada ao Detran-SP. Aguardando o resultado.', 'awaiting-result':'Aguardando o resultado do Detran-SP. Se houver erro ou captcha, conclua na janela do portal.', 'awaiting-validation':'Placa e Renavam preenchidos. Aguardando validação do Detran; conclua o captcha ou a confirmação solicitada.', 'third-party-selected':'Abrindo Veículos de outras pessoas…', 'awaiting-form':'Aguardando o formulário do Detran-SP.', 'login-selected':'Abrindo o login oficial do gov.br…', 'awaiting-login':'Aguardando o login oficial do gov.br…', 'manual-login':'Conclua o login solicitado pelo Detran-SP. O preenchimento da pesquisa continuará automaticamente.'})[step];
}
module.exports = { advance, message };
