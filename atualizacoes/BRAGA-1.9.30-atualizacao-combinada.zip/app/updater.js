'use strict';
const fs = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');
const REPO = 'guicbragadesp/consulta-veicular-sp';
const ASSET = 'Atualizar-Consulta-Veicular-SP.exe';
function version(value) {
  const match = /^v?(\d{1,5})\.(\d{1,5})\.(\d{1,5})$/.exec(value || '');
  if (!match) throw new Error('Versão publicada inválida.');
  return match.slice(1).map(Number);
}
function newer(remote, local) {
  const a = version(remote), b = version(local);
  for (let i = 0; i < 3; i++) { if (a[i] !== b[i]) return a[i] > b[i]; }
  return false;
}
function selectRelease(release, current) {
  if (release.draft || release.prerelease || !newer(release.tag_name, current)) return null;
  const asset = (release.assets || []).find(a => a.name === ASSET && a.state === 'uploaded');
  const expected = 'https://github.com/' + REPO + '/releases/download/' + release.tag_name + '/' + ASSET;
  if (!asset || asset.browser_download_url !== expected || !/^sha256:[a-f0-9]{64}$/.test(asset.digest || '') || !Number.isSafeInteger(asset.size) || asset.size <= 0 || asset.size > 30 * 1024 * 1024)
    throw new Error('A atualização ainda não está pronta para download. Tente novamente mais tarde.');
  return { version: release.tag_name.replace(/^v/, ''), url: expected, hash: asset.digest.slice(7), size: asset.size };
}
async function response(url, timeout, fetcher) {
  for (let i = 0; i < 6; i++) {
    const target = new URL(url);
    if (target.protocol !== 'https:' || target.username || target.password || !['api.github.com','github.com','release-assets.githubusercontent.com','objects.githubusercontent.com'].includes(target.hostname)) throw new Error('Endereço de atualização não autorizado.');
    const r = await fetcher(url, { redirect: 'manual', headers: { 'User-Agent': 'Consulta-Veicular-SP', 'Accept': 'application/vnd.github+json' }, signal: AbortSignal.timeout(timeout) });
    if ([301,302,303,307,308].includes(r.status)) { const next = r.headers.get('location'); await r.body?.cancel(); if (!next) throw new Error('Download indisponível.'); url = new URL(next, url).href; continue; }
    if (!r.ok) { await r.body?.cancel(); throw new Error(r.status === 404 ? 'Ainda não há uma atualização publicada.' : 'Não foi possível consultar o GitHub. Tente novamente mais tarde.'); }
    return r;
  }
  throw new Error('Não foi possível localizar o download da atualização.');
}
async function limitedBody(r, limit) {
  let size = 0; const chunks = [];
  for await (const chunk of r.body) {
    size += chunk.length;
    if (size > limit) throw new Error('O arquivo recebido excede o tamanho permitido.');
    chunks.push(Buffer.from(chunk));
  }
  return Buffer.concat(chunks);
}
async function check(current, fetcher = fetch) {
  const r = await response('https://api.github.com/repos/' + REPO + '/releases/latest', 20000, fetcher);
  return selectRelease(JSON.parse((await limitedBody(r, 1024 * 1024)).toString('utf8')), current);
}
async function download(update, directory, fetcher = fetch) {
  const r = await response(update.url, 120000, fetcher);
  const bytes = await limitedBody(r, update.size);
  if (bytes.length !== update.size || crypto.createHash('sha256').update(bytes).digest('hex') !== update.hash) throw new Error('O download não passou na verificação. Nenhuma atualização foi instalada.');
  await fs.mkdir(directory, { recursive: true });
  const temp = await fs.mkdtemp(path.join(directory, 'consulta-veicular-'));
  const file = path.join(temp, ASSET);
  await fs.writeFile(file, bytes, { flag: 'wx' });
  return file;
}
module.exports = { check, download, newer, selectRelease };

