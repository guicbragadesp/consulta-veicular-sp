'use strict';
(function(root){
 function formatMoneyInput(value){
  const text=String(value??'').trim().replace(/^R\$\s*/, '').replace(/\s/g,'');
  if(!text)return '';
  if(!/^(?:\d+|\d{1,3}(?:\.\d{3})+)(?:,\d{1,2})?$/.test(text))return value;
  const parts=text.replace(/\./g,'').split(',');
  const amount=Number(parts[0])*100+Number((parts[1]||'').padEnd(2,'0'));
  if(!Number.isSafeInteger(amount)||amount>10000000000)return value;
  return (amount/100).toLocaleString('pt-BR',{minimumFractionDigits:2,maximumFractionDigits:2});
 }
 if(typeof module!=='undefined')module.exports={formatMoneyInput};
 else root.formatMoneyInput=formatMoneyInput;
})(typeof window!=='undefined'?window:this);

