'use strict';
// OOXML sem dependências: ZIP armazenado, strings explícitas (sem fórmulas).
const esc = s => String(s).replace(/[\x00-\x08\x0b\x0c\x0e-\x1f]/g,'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
function crc(data) { let c = -1; for (const b of data) { c ^= b; for (let i=0;i<8;i++) c=(c>>>1)^((c&1)?0xedb88320:0); } return (c^-1)>>>0; }
function zip(files) {
  const parts=[], central=[]; let offset=0;
  for (const [name,text] of Object.entries(files)) {
    const n=Buffer.from(name), data=Buffer.from(text), sum=crc(data);
    const h=Buffer.alloc(30); h.writeUInt32LE(0x04034b50); h.writeUInt16LE(20,4); h.writeUInt32LE(sum,14); h.writeUInt32LE(data.length,18); h.writeUInt32LE(data.length,22); h.writeUInt16LE(n.length,26);
    const c=Buffer.alloc(46); c.writeUInt32LE(0x02014b50); c.writeUInt16LE(20,4); c.writeUInt16LE(20,6); c.writeUInt32LE(sum,16); c.writeUInt32LE(data.length,20); c.writeUInt32LE(data.length,24); c.writeUInt16LE(n.length,28); c.writeUInt32LE(offset,42);
    parts.push(h,n,data); central.push(c,n); offset+=h.length+n.length+data.length;
  }
  const index=Buffer.concat(central), end=Buffer.alloc(22); end.writeUInt32LE(0x06054b50); end.writeUInt16LE(Object.keys(files).length,8); end.writeUInt16LE(Object.keys(files).length,10); end.writeUInt32LE(index.length,12); end.writeUInt32LE(offset,16);
  return Buffer.concat([...parts,index,end]);
}
const ns='http://schemas.openxmlformats.org/spreadsheetml/2006/main';
const rel='http://schemas.openxmlformats.org/officeDocument/2006/relationships';
function column(n) { let s=''; do { s=String.fromCharCode(65+n%26)+s; n=Math.floor(n/26)-1; } while(n>=0); return s; }
function printRowHeight(sheet, row, index) {
  if (index === 0) return 28;
  if (row.every(value => value === '')) return 10;
  const lines = Math.max(...row.map((value,col) => Math.max(1, ...String(value).split('\n').map(line=>Math.ceil(line.length / Math.max(12,(sheet.widths[col] || 24)-4))))));
  return Math.max(21,lines * 15 + 6);
}
function rowAttributes(sheet,row,index) {
  return sheet.printLayout ? ' ht="'+printRowHeight(sheet,row,index)+'" customHeight="1"' : index===0 ? ' ht="30" customHeight="1"' : '';
}
function printBreaks(sheet) {
  if (!sheet.printLayout) return '';
  const starts = sheet.rows.map((row,index)=>String(row[0]).startsWith('PLACA: ')?index:-1).filter(index=>index>=0);
  const breaks=[]; let height=sheet.rows.slice(0,starts[0] || 0).reduce((sum,row,index)=>sum+printRowHeight(sheet,row,index),0);
  starts.forEach((start,i)=>{
    const end=i+1<starts.length?starts[i+1]:sheet.rows.length;
    const blockHeight=sheet.rows.slice(start,end).reduce((sum,row,j)=>sum+printRowHeight(sheet,row,start+j),0);
    if(height>0 && height+blockHeight>740 && start>2){breaks.push(start);height=0;}
    height+=blockHeight;
  });
  return breaks.length ? '<rowBreaks count="'+breaks.length+'" manualBreakCount="'+breaks.length+'">'+breaks.map(index=>'<brk id="'+index+'" min="0" max="1" man="1"/>').join('')+'</rowBreaks>' : '';
}
function workbook(sheets) {
  const files={};
  files['[Content_Types].xml']='<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'+sheets.map((_,i)=>'<Override PartName="/xl/worksheets/sheet'+(i+1)+'.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>').join('')+'</Types>';
  files['_rels/.rels']='<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="'+rel+'/officeDocument" Target="xl/workbook.xml"/></Relationships>';
  files['xl/workbook.xml']='<workbook xmlns="'+ns+'" xmlns:r="'+rel+'"><sheets>'+sheets.map((s,i)=>'<sheet name="'+esc(s.name)+'" sheetId="'+(i+1)+'" r:id="rId'+(i+1)+'"/>').join('')+'</sheets></workbook>';
  files['xl/_rels/workbook.xml.rels']='<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'+sheets.map((_,i)=>'<Relationship Id="rId'+(i+1)+'" Type="'+rel+'/worksheet" Target="worksheets/sheet'+(i+1)+'.xml"/>').join('')+'<Relationship Id="styles" Type="'+rel+'/styles" Target="styles.xml"/></Relationships>';
  files['xl/styles.xml']='<styleSheet xmlns="'+ns+'"><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FFDDEBF7"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="2"><border/><border><left style="thin"><color rgb="FFB8C4CE"/></left><right style="thin"><color rgb="FFB8C4CE"/></right><top style="thin"><color rgb="FFB8C4CE"/></top><bottom style="thin"><color rgb="FFB8C4CE"/></bottom></border></borders><cellStyleXfs count="1"><xf/></cellStyleXfs><cellXfs count="7"><xf fontId="0"/><xf numFmtId="4" applyNumberFormat="1"/><xf fontId="1" applyFont="1" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf><xf borderId="1" applyBorder="1" applyAlignment="1"><alignment wrapText="1" vertical="center"/></xf><xf borderId="1" numFmtId="4" applyBorder="1" applyNumberFormat="1"/><xf borderId="1" fontId="1" fillId="2" applyFill="1" applyBorder="1" applyFont="1" applyAlignment="1"><alignment wrapText="1" vertical="center"/></xf><xf borderId="1" fontId="1" fillId="2" applyFill="1" numFmtId="4" applyBorder="1" applyFont="1" applyNumberFormat="1"/></cellXfs></styleSheet>';
  sheets.forEach((s,i)=>{ const end=column(s.rows[0].length-1)+s.rows.length; files['xl/worksheets/sheet'+(i+1)+'.xml']='<worksheet xmlns="'+ns+'"><sheetPr><pageSetUpPr fitToPage="1"/></sheetPr><sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><cols>'+s.rows[0].map((_,j)=>'<col min="'+(j+1)+'" max="'+(j+1)+'" width="'+((s.widths || (s.name === 'Resumo por veículo' ? [12,16,28,8,14,13,13,20,20,44,24] : [12,16,18,48,17,14]))[j] || 20)+'" customWidth="1"/>').join('')+'</cols><sheetData>'+s.rows.map((row,r)=>'<row r="'+(r+1)+'"'+rowAttributes(s,row,r)+'>'+row.map((v,c)=>{const ref=column(c)+(r+1); const bold=s.cards ? s.boldRows.includes(r) : r===0; const boxed=s.cards && row.some(x=>x!=='');return typeof v==='number'?'<c r="'+ref+'" s="'+(boxed?(bold?6:4):1)+'"><v>'+v+'</v></c>':'<c r="'+ref+'" t="inlineStr" s="'+(boxed?(bold?5:3):(bold?2:0))+'"><is><t xml:space="preserve">'+esc(v)+'</t></is></c>';}).join('')+'</row>').join('')+'</sheetData>'+(s.cards?'':'<autoFilter ref="A1:'+end+'"/>')+'<printOptions horizontalCentered="1"/><pageMargins left="0.25" right="0.25" top="0.4" bottom="0.4" header="0.15" footer="0.15"/><pageSetup paperSize="9" orientation="'+(s.cards?'portrait':'landscape')+'" fitToWidth="1" fitToHeight="0"/>'+printBreaks(s)+'</worksheet>'; });
  return zip(files);
}
module.exports={workbook};

