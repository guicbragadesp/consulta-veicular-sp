'use strict';
function normalize(value) {
  if (value && value.cpf && value.password) return { accounts: [{ ...value, name: 'Meu login' }], active: value.cpf };
  return value && Array.isArray(value.accounts) ? value : { accounts: [], active: null };
}
function save(store, { cpf, password, name }) {
  cpf = String(cpf || '').replace(/\D/g, '');
  if (!/^\d{11}$/.test(cpf)) throw new Error('Informe um CPF com 11 dígitos.');
  const existing = store.accounts.find(a => a.cpf === cpf);
  password = String(password || existing?.password || '');
  if (!password) throw new Error('Informe a senha deste login.');
  const account = { cpf, password, name: String(name || existing?.name || 'Meu login').trim().slice(0, 60) };
  return { accounts: [...store.accounts.filter(a => a.cpf !== cpf), account], active: cpf };
}
function remove(store, cpf) {
  const accounts = store.accounts.filter(a => a.cpf !== cpf);
  return { accounts, active: store.active === cpf ? (accounts[0]?.cpf || null) : store.active };
}
function select(store, cpf) {
  if (!store.accounts.some(a => a.cpf === cpf)) throw new Error('Selecione um login salvo.');
  return { ...store, active: cpf };
}
function publicList(store) { return { active: store.active, accounts: store.accounts.map(({ cpf, name }) => ({ cpf, name })) }; }
module.exports = { normalize, save, remove, select, publicList };

