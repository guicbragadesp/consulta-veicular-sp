'use strict';
const URL_DETRAN = 'https://www.detran.sp.gov.br/detransp/pb/servicos/veiculos/consultar_debitos_restricoes?id=consultar_debitos_restricoes';
const detranFlow = require('./detran-flow');
const portalScripts = require('./portal-scripts');
const titles = ['Bloqueio de furto/roubo', 'Restrição tributária', 'Restrição financeira', 'Restrição administrativa', 'Restrição judicial', 'Restrição por veículo guinchado'];
const clean = value => String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, ' ').trim().toLowerCase();
const plate = value => String(value || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
const renavam = value => String(value || '').replace(/\D/g, '').replace(/^0+/, '') || '0';
function parse(snapshot, input) {
  const result = { input, status: 'pending', rows: [], alerts: [], message: 'Faça a consulta no Detran-SP. Login e captcha são concluídos por você.' };
  if (!snapshot?.plate || !snapshot.renavam) return result;
  if (plate(snapshot.plate) !== plate(input.plate) || renavam(snapshot.renavam) !== renavam(input.renavam)) {
    result.message = 'O resultado do Detran é de outro veículo. Consulte a placa e o Renavam indicados acima.';
    return result;
  }
  const rows = snapshot.rows || [];
  for (const title of titles) {
    const matches = rows.filter(row => clean(row.title) === clean(title));
    if (matches.length !== 1 || !matches[0].value?.trim()) continue;
    const value = matches[0].value.trim().slice(0, 1000);
    const text = clean(value);
    const clear = text === 'nada consta' || (title === 'Restrição judicial' && /^nao consta bloqueio judicial(?:\s*[-–—]\s*renajud)?\.?$/.test(text));
    const row = { title, value, alert: !clear };
    result.rows.push(row);
    if (row.alert) result.alerts.push(row);
  }
  // Unexpected categories also require attention; they must never silently disappear.
  for (const row of rows.filter(row => !titles.some(title => clean(title) === clean(row.title)))) {
    if (!row.title || !row.value) continue;
    const item = { title: row.title.slice(0, 150), value: row.value.slice(0, 1000), alert: clean(row.value) !== 'nada consta' };
    result.rows.push(item); if (item.alert) result.alerts.push(item);
  }
  const complete = titles.every(title => result.rows.some(row => row.title === title));
  if (snapshot.fuel?.trim()) {
    const fuel = snapshot.fuel.trim().slice(0, 250);
    const row = { title: 'Combustível', value: fuel, alert: /\bgnv\b|gas natural/.test(clean(fuel)) };
    result.rows.push(row); if (row.alert) result.alerts.push(row);
  }
  result.status = complete && !!snapshot.fuel?.trim() ? 'complete' : 'pending';
  result.message = result.alerts.length ? 'ATENÇÃO: há restrição ou informação que precisa de conferência no Detran-SP.' : result.status === 'complete' ? 'Nenhuma restrição indicada nas seis categorias consultadas. Combustível sem indicação de GNV.' : 'Leitura incompleta. Confira a página do Detran; ausência de informação não significa Nada consta.';
  return result;
}
// Reads only visible vehicle identity and restriction values; never credentials.
function rowsFromText(text) {
  const lines = String(text || '').split(/\r?\n/).map(line => line.trim()).filter(Boolean);
  const rows = [];
  for (let i = 0; i < lines.length; i++) {
    const title = titles.find(title => clean(title) === clean(lines[i]));
    if (!title) continue;
    const values = [];
    while (++i < lines.length && !titles.some(title => clean(title) === clean(lines[i]))) values.push(lines[i]);
    i--;
    if (values.length) rows.push({ title, value: values.join(' ') });
  }
  return rows;
}
function snapshotPage() {
  const normalize = value => String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, ' ').trim().toLowerCase();
  const categories = ['Bloqueio de furto/roubo', 'Restrição tributária', 'Restrição financeira', 'Restrição administrativa', 'Restrição judicial', 'Restrição por veículo guinchado'];
  const visible = el => !!el && !!el.getClientRects().length && getComputedStyle(el).visibility !== 'hidden';
  if (visible(document.querySelector('[role="dialog"]'))) return null;
  const vehicle = document.getElementById('vehicleInfo');
  const section = document.querySelector('.restricoes-section');
  if (!visible(vehicle)) return null;
  const label = Array.from(vehicle.querySelectorAll('label')).find(el => el.textContent.trim().toLowerCase() === 'renavam');
  const fuelLabel = Array.from(vehicle.querySelectorAll('label')).find(el => el.textContent.trim().toLowerCase() === 'combustível');
  // The heading and the cards can be in separate containers. Find each visible
  // category by its text, then read the smallest ancestor holding its value.
  const elements = Array.from(document.querySelectorAll('body *')).filter(visible);
  const rows = [];
  for (const title of categories) {
    const headings = elements.filter(el => normalize(el.innerText) === normalize(title) &&
      !Array.from(el.children).some(child => visible(child) && normalize(child.innerText) === normalize(title)));
    for (const heading of headings) {
      let container = heading.parentElement;
      while (container && container !== document.body) {
        const text = container.innerText?.trim() || '';
        const normalized = normalize(text);
        if (categories.some(other => other !== title && normalized.includes(normalize(other)))) break;
        const headingText = heading.innerText.trim();
        const offset = text.indexOf(headingText);
        const value = offset < 0 ? '' : text.slice(offset + headingText.length).trim();
        if (value && value.length <= 1000) { rows.push({title, value}); break; }
        container = container.parentElement;
      }
    }
  }
  return {
    plate: vehicle.querySelector('placa-veiculo')?.getAttribute('placa')?.match(/^[A-Za-z0-9-]+$/) ? vehicle.querySelector('placa-veiculo').getAttribute('placa') : vehicle.querySelector('#placaContainer placa-veiculo')?.innerText.trim(),
    renavam: label?.nextElementSibling?.innerText.trim(),
    fuel: fuelLabel?.nextElementSibling?.innerText.trim(),
    rows: rows.length ? rows : Array.from(section?.querySelectorAll('.restriction-item') || []).filter(visible).map(el => ({ title: el.querySelector('.restriction-title')?.innerText.trim(), value: el.querySelector('.restriction-situation')?.innerText.trim() })),
    restrictionText: visible(section) ? section.innerText : ''
  };
}
function createController({ BrowserWindow, navigationGuard, icon, onResult, getCredential = async () => null }) {
  let win, input, timer, busy = false, serial = 0, previous = '', lastAlert = '', returned = false;
  function reset() {
    serial++; clearInterval(timer); timer = null; input = null; previous = ''; lastAlert = ''; returned = false;
    if (win && !win.isDestroyed()) win.destroy(); win = null;
  }
  function publish(result) {
    const key = JSON.stringify(result);
    if (key !== previous) { previous = key; onResult(result); }
  }
  async function tick() {
    if (busy || !input || !win || win.isDestroyed()) return;
    const token = serial, current = win, expected = input;
    try {
      const url = new URL(current.webContents.getURL());
      if (url.protocol === 'https:' && url.hostname === 'sso.acesso.gov.br') {
        busy = true;
        const credentials = await getCredential();
        if (token !== serial) return;
        const step = credentials ? await current.webContents.executeJavaScript(portalScripts.script(portalScripts.fillGovLogin, credentials)) : 'no-login';
        if (token !== serial) return;
        const mismatch = ['different-password','different-cpf'].includes(step);
        publish({ ...parse(null, expected), message: mismatch ? 'O gov.br está preenchido com outro login. Confira na janela do Detran; o Braga preservou os dados digitados.' : credentials ? 'Usando o login gov.br selecionado. Conclua o captcha ou a verificação adicional, se solicitado.' : 'Cadastre um login gov.br no Braga ou faça o login diretamente no Detran. A pesquisa continuará automaticamente.' });
        return;
      }
      if (url.protocol !== 'https:' || !['www.detran.sp.gov.br', 'detran.sp.gov.br'].includes(url.hostname)) return;
      busy = true;
      const snapshot = await current.webContents.executeJavaScript('(' + snapshotPage.toString() + ')()');
      if (token !== serial) return;
      if (snapshot?.restrictionText) {
        const fallback = rowsFromText(snapshot.restrictionText);
        snapshot.rows = titles.flatMap(title => {
          const direct = (snapshot.rows || []).filter(row => clean(row.title) === clean(title) && row.value?.trim());
          return direct.length ? direct : fallback.filter(row => row.title === title);
        }).concat((snapshot.rows || []).filter(row => row.title && !titles.some(title => clean(title) === clean(row.title))));
      }
      const result = parse(snapshot, expected);
      if (!snapshot) {
        const step = await current.webContents.executeJavaScript(portalScripts.script(detranFlow.advance, expected));
        if (token !== serial) return;
        if (step === 'return-to-service' && !returned) {
          returned = true; await current.loadURL(URL_DETRAN); return;
        }
        result.message = detranFlow.message(step) || result.message;
      }
      publish(result);
      const alertKey = JSON.stringify(result.alerts);
      if (!result.alerts.length && result.status === 'complete') lastAlert = '';
      if (result.alerts.length && alertKey !== lastAlert) {
        lastAlert = alertKey;
        // A persistent alert also remains visible in the main window.
        const { dialog } = require('electron');
        void dialog.showMessageBox(current, { type: 'warning', title: 'Atenção ao veículo — Restrições / GNV', message: expected.plate + ' — Detran-SP', detail: result.alerts.map(row => row.title + ': ' + row.value).join('\n'), buttons: ['Entendi'] });
      }
    } catch { if (token === serial) publish({ ...parse(null, expected), message: 'Não foi possível ler o Detran. Confira a página e tente a consulta novamente.' }); }
    finally { busy = false; }
  }
  async function open(value) {
    const normalized = { plate: plate(value?.plate), renavam: String(value?.renavam || '').replace(/\D/g, '') };
    if (!/^[A-Z]{3}[0-9][A-Z0-9][0-9]{2}$/.test(normalized.plate) || !/^\d{9,11}$/.test(normalized.renavam) || /^0+$/.test(normalized.renavam)) throw new Error('Informe uma placa e um Renavam válidos antes de consultar restrições.');
    reset(); input = normalized;
    const current = new BrowserWindow({ width: 1120, height: 820, icon, title: 'Restrições · Detran-SP · BRAGA', autoHideMenuBar: true, webPreferences: { nodeIntegration: false, contextIsolation: true, sandbox: true, partition: 'persist:portais-sp' } });
    win = current;
    const guard = navigationGuard(() => publish({ ...parse(null, normalized), message: 'Endereço não reconhecido. A consulta não foi concluída.' }));
    current.webContents.on('will-navigate', guard); current.webContents.on('will-redirect', guard);
    current.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
    current.webContents.on('did-finish-load', () => { void tick(); });
    current.on('closed', () => { if (win === current) { win = null; clearInterval(timer); } });
    publish(parse(null, normalized)); timer = setInterval(tick, 2000);
    const token = serial;
    try { await current.loadURL(URL_DETRAN); } catch { if (token === serial) publish({ ...parse(null, normalized), message: 'O Detran não carregou. Verifique sua conexão e tente novamente.' }); }
  }
  return { open, reset };
}
module.exports = { parse, rowsFromText, snapshotPage, createController, URL_DETRAN };
