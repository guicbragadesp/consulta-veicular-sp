'use strict';
(function(root) {
  const extra = row => !row.source && row.id !== 'honorarios';
  function rows(state) {
    const official = [...(state.fazenda?.rows || []), ...(state.pge?.rows || [])];
    const ipva = row => /\bIPVA\b/i.test(row.description || '');
    const extras = (state.input?.extras || []).filter(row => row.cents > 0);
    const honorarios = extras.filter(row => row.id === 'honorarios');
    const order = ['transfer', 'inspection', 'plateService'];
    const fixed = order.flatMap(id => extras.filter(row => row.id === id));
    const other = extras.filter(row => row.id !== 'honorarios' && !order.includes(row.id));
    return [...official.filter(ipva), ...official.filter(row => !ipva(row)), ...honorarios, ...fixed, ...other];
  }
  const api = { rows, extra };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.quoteLayout = api;
})(typeof window !== 'undefined' ? window : globalThis);

