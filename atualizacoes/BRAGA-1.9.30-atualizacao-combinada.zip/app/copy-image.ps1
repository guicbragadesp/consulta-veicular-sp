param([Parameter(Mandatory=$true)][string]$ImagePath)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$image = [System.Drawing.Image]::FromFile($ImagePath)
try {
  $copied = $false
  for ($attempt = 0; $attempt -lt 5; $attempt++) {
    try {
      [System.Windows.Forms.Clipboard]::SetDataObject($image, $true)
      $copied = $true
      break
    } catch { Start-Sleep -Milliseconds 200 }
  }
  if (-not $copied) { throw 'Clipboard unavailable' }
} finally { $image.Dispose() }
